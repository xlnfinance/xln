/**
 * Bun worker transport for the portable Wasm backend.
 * All cryptographic choices remain in spec.ts/kdf.ts; this file only moves one
 * indexed shard across a worker-thread boundary and returns strict hex.
 */
import { parentPort } from 'worker_threads';
import { bytesToHex } from './primitives/encoding.ts';
import { deriveShardWithParams } from './primitives/kdf.ts';
import { BRAINVAULT_V1, BRAINVAULT_V1_SPEC_ID, createShardSalt } from './primitives/spec.ts';

parentPort?.on('message', async ({ specId, name, passphrase, shardIndex, shardCount, shardMemoryKb, algId }) => {
  if (specId !== BRAINVAULT_V1_SPEC_ID) {
    throw new Error(`BRAINVAULT_WORKER_SPEC_MISMATCH:${String(specId)}:${BRAINVAULT_V1_SPEC_ID}`);
  }
  const memoryKb = shardMemoryKb ?? BRAINVAULT_V1.SHARD_MEMORY_KB;
  const salt = await createShardSalt(name, shardIndex, shardCount, algId ?? BRAINVAULT_V1.ALG_ID);
  const result = await deriveShardWithParams(passphrase, salt, {
    shardMemoryKb: memoryKb,
    algId: algId ?? BRAINVAULT_V1.ALG_ID,
  });
  parentPort?.postMessage({ specId: BRAINVAULT_V1_SPEC_ID, shardIndex, result: bytesToHex(result) });
});
