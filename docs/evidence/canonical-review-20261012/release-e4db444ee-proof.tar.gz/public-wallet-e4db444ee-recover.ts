import { chromium, expect } from '../../ui/node_modules/@playwright/test';
import { readFileSync, writeFileSync } from 'node:fs';
import { LOCAL_PASSWORD } from '../../ui/tests/stack';
const base='https://sepolia.xln.finance';
const dir='/Users/zigota/.config/xln/sepolia-demo-e4db444ee';
const journal=dir+'/actions.json';
const previous=JSON.parse(readFileSync(journal,'utf8'));
expect(previous.stage).toBe('paid-25-USDT');
const context=await chromium.launchPersistentContext(dir+'/browser',{headless:true,viewport:{width:1280,height:860}});
const page=context.pages()[0] ?? await context.newPage();
for(const other of context.pages())if(other!==page)await other.close();
const errors:string[]=[];const financialRequests:string[]=[];
page.on('pageerror',e=>errors.push(e.message));
page.on('request',r=>{if(r.method()==='POST'&&new URL(r.url()).pathname.startsWith('/api/faucet'))financialRequests.push(new URL(r.url()).pathname);});
async function unlock(){
 await expect(page.getByRole('button',{name:'Continue',exact:true})).toBeVisible({timeout:15000});
 await page.getByRole('button',{name:'Continue',exact:true}).click();
 await page.getByLabel('Password',{exact:true}).fill(LOCAL_PASSWORD);
 await page.getByRole('button',{name:'Unlock',exact:true}).click();
 await expect(page.getByTestId('nav-home').locator('visible=true').first()).toBeVisible({timeout:30000});
}
async function assets(){await page.getByTestId('nav-manage').locator('visible=true').first().click();await page.getByTestId('manage-assets').click();}
try{
 const response=await page.goto(base+'/assets');expect(response?.status()).toBe(200);
 await unlock();await assets();
 await expect(page.getByTestId('faucet-account-balance')).toHaveText('75.00 USDT',{timeout:15000});
 console.log('PUBLIC_RECOVERY_STAGE existing-profile-75-USDT');
 expect((await page.reload({waitUntil:'domcontentloaded'}))?.status()).toBe(200);
 await unlock();await assets();
 await expect(page.getByTestId('faucet-account-balance')).toHaveText('75.00 USDT',{timeout:15000});
 await page.getByTestId('nav-home').locator('visible=true').first().click();
 expect(errors).toEqual([]);expect(financialRequests).toEqual([]);
 expect(await page.evaluate(()=>'__xln' in window)).toBe(false);
 await page.screenshot({path:'.logs/canonical-review-20261012/public-wallet-e4db444ee.png',fullPage:true});
 writeFileSync(journal,JSON.stringify({stage:'reload-verified',previous,at:new Date().toISOString()}),{mode:0o600});
 console.log(JSON.stringify({kind:'PUBLIC_WALLET_RECOVERY_VERIFIED',origin:base,sourceSha:'e4db444ee98abf9cc567b8f9bd431d97c1414b95',funded:'100.00 USDT',paid:'25.00 USDT',balance:'75.00 USDT',reloadsVerified:2,additionalFunding:0,additionalPayments:0,errors}));
}catch(e){console.log('PUBLIC_RECOVERY_ERROR '+(e instanceof Error?e.message:String(e)));await page.screenshot({path:dir+'/recovery-failure.png',fullPage:true});process.exitCode=1;}
finally{await context.close();}
