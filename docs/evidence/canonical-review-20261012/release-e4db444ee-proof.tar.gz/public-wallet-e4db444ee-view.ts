import { chromium, expect } from '../../ui/node_modules/@playwright/test';
import { LOCAL_PASSWORD } from '../../ui/tests/stack';
const dir='/Users/zigota/.config/xln/sepolia-demo-e4db444ee';
const context=await chromium.launchPersistentContext(dir+'/browser',{headless:true,viewport:{width:1280,height:860}});
const page=context.pages()[0]??await context.newPage();
for(const other of context.pages())if(other!==page)await other.close();
const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
try {
 expect((await page.goto('https://sepolia.xln.finance'))?.status()).toBe(200);
 await page.getByRole('button',{name:'Continue',exact:true}).click();
 await page.getByLabel('Password',{exact:true}).fill(LOCAL_PASSWORD);
 await page.getByRole('button',{name:'Unlock',exact:true}).click();
 await expect(page.getByTestId('home-total')).toContainText('75.00',{timeout:30000});
 await expect(page.getByTestId('account-row').first()).toBeVisible();
 await page.screenshot({path:'.logs/canonical-review-20261012/public-wallet-e4db444ee.png',fullPage:true});
 expect(errors).toEqual([]);
 console.log(JSON.stringify({kind:'PUBLIC_HOME_VISIBLE',total:await page.getByTestId('home-total').textContent(),errors}));
}finally{await context.close();}
