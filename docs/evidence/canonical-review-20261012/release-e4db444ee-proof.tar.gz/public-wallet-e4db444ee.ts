import { chromium, expect } from '../../ui/node_modules/@playwright/test';
import { HDNodeWallet } from 'ethers';
import { mkdirSync, existsSync, writeFileSync, readFileSync } from 'node:fs';
import { importStackPhraseUi, LOCAL_PASSWORD } from '../../ui/tests/stack';
const base='https://sepolia.xln.finance';
const dir='/Users/zigota/.config/xln/sepolia-demo-e4db444ee';
mkdirSync(dir,{recursive:true,mode:0o700});
const seedFile=dir+'/seed.mnemonic';
if(!existsSync(seedFile)){const phrase=HDNodeWallet.createRandom().mnemonic?.phrase;if(!phrase)throw Error('MNEMONIC_MISSING');writeFileSync(seedFile,phrase,{mode:0o600});}
const journal=dir+'/actions.json';
if(existsSync(journal)) throw Error('PUBLIC_DEMO_ALREADY_STARTED_INSPECT_SAVED_PROFILE_BEFORE_RETRY');
const context=await chromium.launchPersistentContext(dir+'/browser',{headless:true,viewport:{width:1280,height:860}});
const page=await context.newPage();const errors:string[]=[];const requests:string[]=[];
page.on('pageerror',e=>errors.push(e.message));
page.on('request',r=>{if(r.method()==='POST'&&new URL(r.url()).pathname.startsWith('/api/faucet'))requests.push(new URL(r.url()).pathname);});
const stage=(name:string)=>{writeFileSync(journal,JSON.stringify({stage:name,at:new Date().toISOString()}),{mode:0o600});console.log('PUBLIC_DEMO_STAGE '+name);};
const home=()=>page.getByTestId('nav-home').locator('visible=true').first().click();
const assets=async()=>{await page.getByTestId('nav-manage').locator('visible=true').first().click();await page.getByTestId('manage-assets').click();};
try {
 const health=await (await fetch(base+'/api/health')).json();expect(health.source.gitHead).toBe('e4db444ee98abf9cc567b8f9bd431d97c1414b95');expect(health.coreOk).toBe(true);expect(health.systemOk).toBe(true);
 await page.goto(base);
 if(await page.getByRole('button',{name:'Continue',exact:true}).isVisible()){
 await page.getByRole('button',{name:'Continue',exact:true}).click();await page.getByLabel('Password',{exact:true}).fill(LOCAL_PASSWORD);await page.getByRole('button',{name:'Unlock',exact:true}).click();
 await expect(page.getByTestId('nav-home').locator('visible=true').first()).toBeVisible({timeout:120000});
 }else await importStackPhraseUi(page,readFileSync(seedFile,'utf8').trim());
 stage('wallet-open');
 expect(await page.evaluate(()=>'__xln' in window)).toBe(false);
 await expect(page.getByTestId('account-row').first()).toBeVisible({timeout:45000});
 const before=await page.getByTestId('home-total').textContent();
 stage('faucet-requesting');await page.getByTestId('home-faucet').click();
 await expect(page.getByTestId('test-money-status')).toHaveText('100 USDT received',{timeout:45000});stage('funded-100-USDT');
 await assets();await expect(page.getByTestId('faucet-account-balance')).toHaveText('100.00 USDT',{timeout:15000});await home();
 await page.getByTestId('home-pay').click();await page.getByTestId('pay-to').fill('H1');await page.getByTestId('pay-amount').fill('25');
 await expect(page.getByTestId('pay-submit')).toBeEnabled({timeout:15000});
 const quote=page.getByTestId('pay-quote');await expect(quote).toHaveAttribute('data-recipient-amount','25000000');
 const sender=BigInt((await quote.getAttribute('data-sender-amount'))!);const fee=BigInt((await quote.getAttribute('data-fee-amount'))!);expect(sender).toBe(25000000n+fee);
 expect(fee).toBeGreaterThanOrEqual(0n);expect(fee).toBeLessThan(1_000_000n);
 const cents=(100_000_000n-sender+5_000n)/10_000n;const expectedBalance=`${cents/100n}.${String(cents%100n).padStart(2,'0')} USDT`;
 stage('payment-requesting');await page.getByTestId('pay-submit').click();await page.getByTestId('receipt-open').click();
 await expect(page.getByTestId('receipt-kicker')).toHaveText('Paid',{timeout:15000});await expect(page.getByTestId('receipt-amount')).toHaveText('25.00 USDT');stage('paid-25-USDT');
 await expect(page.getByTestId('receipt-title')).toContainText('H1');
 await page.getByTestId('receipt-done').click();await assets();await expect(page.getByTestId('faucet-account-balance')).toHaveText(expectedBalance,{timeout:15000});
 await page.reload({waitUntil:'domcontentloaded'});await page.getByRole('button',{name:'Continue',exact:true}).click();await page.getByLabel('Password',{exact:true}).fill(LOCAL_PASSWORD);await page.getByRole('button',{name:'Unlock',exact:true}).click();
 await assets();await expect(page.getByTestId('faucet-account-balance')).toHaveText(expectedBalance,{timeout:30000});await home();expect(errors).toEqual([]);expect(requests).toEqual(['/api/faucet/offchain']);
 await page.screenshot({path:'.logs/canonical-review-20261012/public-wallet-e4db444ee.png',fullPage:true});stage('reload-verified');
 console.log(JSON.stringify({kind:'PUBLIC_WALLET_VERIFIED',origin:base,before,expectedBalance,senderAmount:sender.toString(),fee:fee.toString(),requests,errors,sourceSha:'e4db444ee98abf9cc567b8f9bd431d97c1414b95'}));
} catch(e){console.log('PUBLIC_DEMO_ERROR '+(e instanceof Error?e.message:String(e)));await page.screenshot({path:dir+'/failure.png',fullPage:true});process.exitCode=1;}
finally{await context.close();}
