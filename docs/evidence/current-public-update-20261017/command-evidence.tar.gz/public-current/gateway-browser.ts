import { fetchLoopback } from '/Users/zigota/xln/core/orchestrator/server/loopback-fetch';
import { chromium, expect } from '/Users/zigota/xln/ui/node_modules/@playwright/test/index.mjs';
import { HDNodeWallet } from '/Users/zigota/xln/node_modules/ethers/lib.esm/index.js';
import { importStackPhraseUi, LOCAL_PASSWORD } from '/Users/zigota/xln/ui/tests/stack.ts';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
export async function verifyGateway(mode:string, out:string, origin='http://localhost:8080') {
  const events:unknown[]=[]; const errors:string[]=[]; const workers:string[]=[]; let relayFrames=0;
  const browser=await chromium.launch({headless:true});
  const hash=(bytes:Uint8Array)=>createHash('sha256').update(bytes).digest('hex');
  try {
    const context=await browser.newContext({ignoreHTTPSErrors: origin.startsWith('https://localhost:'), viewport:{width:1440,height:900}});
    context.on('page',page=>{
      page.on('requestfailed',r=>events.push({kind:'requestfailed',url:r.url(),error:r.failure()?.errorText}));
      page.on('pageerror',e=>{errors.push(e.message);events.push({kind:'pageerror',text:e.message});});
      page.on('console',m=>{if(['error','warning'].includes(m.type()))events.push({kind:m.type(),text:m.text()});});
      page.on('worker',worker=>workers.push(worker.url()));
      page.on('websocket',ws=>{events.push({kind:'websocket',url:ws.url()});if(new URL(ws.url()).pathname==='/relay')ws.on('framereceived',()=>relayFrames++);});
      page.on('response',r=>{if(r.status()>=400)events.push({kind:'http',url:r.url(),status:r.status()});});
    });
    const page=await context.newPage();
    await page.goto(origin+'/app');
    await expect(page).toHaveURL(origin+'/ui/');
    await expect(page.getByTestId('gate-stack')).toHaveAttribute('data-state','online',{timeout:20000});
    const phrase=HDNodeWallet.createRandom().mnemonic?.phrase; if(!phrase)throw new Error('MNEMONIC_MISSING');
    await importStackPhraseUi(page,phrase);
    await expect(page.getByTestId('account-row').first()).toBeVisible({timeout:15000});
    expect(workers.some(url=>new URL(url).pathname==='/account-worker.js')).toBe(true);
    expect(relayFrames).toBeGreaterThan(1);
    const assets=[];
    for(const [path,file] of [['/ui/runtime.js','runtime.js'],['/account-worker.js','account-worker.js']]){
      const response=await fetchLoopback(origin+path); const bytes=new Uint8Array(await response.arrayBuffer());
      expect(response.status).toBe(200); expect(response.headers.get('content-type')).toMatch(/javascript/);
      const expected=hash(readFileSync('/Users/zigota/xln/frontend/static/'+file));
      expect(hash(bytes)).toBe(expected);assets.push({path,sha256:expected,bytes:bytes.length,mime:response.headers.get('content-type')});
    }
    await page.goto(origin+'/ui/manage');
    await page.reload();
    await expect(page).toHaveURL(origin+'/ui/manage');
    await page.getByRole('button',{name:'Continue',exact:true}).click();
    await page.getByLabel('Password',{exact:true}).fill(LOCAL_PASSWORD);
    await page.getByRole('button',{name:'Unlock',exact:true}).click();
    await page.getByTestId('nav-manage').locator('visible=true').first().click();
    await page.getByTestId('manage-custom-contracts').click();
    await expect(page.getByTestId('custom-unavailable')).toContainText('New custom-contract admission is unavailable');
    await expect(page.getByTestId('custom-source')).not.toHaveValue('');
    await page.getByTestId('custom-compile').click();
    await expect(page.getByTestId('custom-compiled')).toContainText('0.8.36',{timeout:10000});
    await expect(page.getByRole('button',{name:'Propose to counterparty'})).toHaveCount(0);
    await page.screenshot({path:out+'/'+mode+'-wallet.png'});
    const graph=await context.newPage(); await graph.goto(origin+'/embed?trail=ahb&present=1');
    await expect(graph.getByTestId('presentation-narration')).toBeVisible({timeout:15000});
    await graph.screenshot({path:out+'/'+mode+'-observer.png'});
    expect(errors).toEqual([]);
    expect(events.filter((event:any)=>['error','http','requestfailed'].includes(event.kind))).toEqual([]);
    const evidence={mode,origin,assets,workers,relayFrames,pageErrors:errors,checks:['app redirect','fresh embedded wallet/account','current runtime and worker MIME/hash','real worker initialization','relay traffic','deep route reload/unlock','compile with unavailable admission','observer graph']};
    writeFileSync(out+'/'+mode+'-gateway-evidence.json',JSON.stringify(evidence,null,2)+'\n');
    console.log('CANONICAL_GATEWAY_OK '+JSON.stringify(evidence));
  }finally{writeFileSync(out+'/'+mode+'-gateway-console.json',JSON.stringify(events,null,2)+'\n');await browser.close();}
}
