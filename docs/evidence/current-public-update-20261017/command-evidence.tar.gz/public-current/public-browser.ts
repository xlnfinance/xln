import { spawn } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';
import { verifyGateway } from '/Users/zigota/agent-jobs/xln-mainnet-autonomy-20261017/public-current/gateway-browser';
const out='/Users/zigota/agent-jobs/xln-mainnet-autonomy-20261017/public-current/browser';mkdirSync(out,{recursive:true});
const remote=spawn('ssh',['-o','BatchMode=yes','-o','ConnectTimeout=5','xln.finance',`cd /root/xln && export PATH=/root/.local/share/xln/toolchains/bun-1.4.0:/root/.bun/bin:/root/.foundry/bin:$PATH && bun run stand:status && bun run stand:run --reason public-browser-current --timeout-ms 60000 -- python3 -u -c 'import sys; print("PUBLIC_BROWSER_STAND_READY",flush=True); sys.stdin.buffer.read()'`],{stdio:['pipe','pipe','pipe']});
let log='';let ready=false;let exit:number|null=null;
remote.stdout.on('data',b=>{log+=b.toString();if(log.includes('PUBLIC_BROWSER_STAND_READY'))ready=true;});
remote.stderr.on('data',b=>{log+=b.toString();});
const exited=new Promise<void>((resolve,reject)=>{remote.on('exit',code=>{exit=code;resolve();});remote.on('error',reject);});
try{
 const deadline=Date.now()+10000;
 while(!ready){if(exit!==null)throw new Error('REMOTE_STAND_EXIT:'+exit);if(Date.now()>deadline)throw new Error('REMOTE_STAND_ACQUIRE_TIMEOUT');await Bun.sleep(50);}
 await verifyGateway('public',out,'https://xln.finance');
}finally{
 remote.stdin.end();await exited;writeFileSync(out+'/remote-stand.log',log);if(exit!==0)throw new Error('REMOTE_STAND_EXIT:'+exit);
}
