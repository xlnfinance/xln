#!/bin/bash
set -euo pipefail
ssh -o BatchMode=yes -o ConnectTimeout=10 xln.finance 'cd /root/xln && python3 -' <<'PY'
import subprocess,json,urllib.request
from pathlib import Path
def call(*args):return subprocess.check_output(args,text=True,timeout=15).strip()
apps=json.loads(call('pm2','jlist'))
rows=[]
for app in apps:
 env=app.get('pm2_env',{})
 rows.append({k:v for k,v in dict(name=app.get('name'),pid=app.get('pid'),status=env.get('status'),startedAt=env.get('pm_uptime'),interpreter=env.get('exec_interpreter'),script=env.get('pm_exec_path'),cwd=env.get('pm_cwd'),treeKill=env.get('treekill'),killTimeout=env.get('kill_timeout')).items()})
request=urllib.request.Request('https://xln.finance/rpc',data=json.dumps({'jsonrpc':'2.0','id':1,'method':'eth_chainId','params':[]}).encode(),headers={'Content-Type':'application/json'})
with urllib.request.urlopen(request,timeout=10) as response:chain=json.load(response)
print(json.dumps({'head':call('git','rev-parse','HEAD'),'branch':call('git','branch','--show-current'),'status':call('git','status','--short'),'chain':chain,'apps':rows},indent=2))
PY
