import hashlib,json,pathlib,subprocess,sys,tarfile,urllib.request,stat
r=pathlib.Path('/root/xln');out=pathlib.Path('/root/xln-deployment-evidence/efb6f5d41/current-update');mode=sys.argv[1];assert mode in ['rollback','restore'];target='efb6f5d4181114457cf3d62077c5d624b9fef9b3'
def run(*args):return subprocess.check_output(args,cwd=r,text=True,timeout=20).strip()
def apps():return {a['name']:{'pid':a['pid'],'status':a['pm2_env']['status']} for a in json.loads(run('pm2','jlist'))}
def protected():
 for n,v in json.loads(pathlib.Path('/root/xln-deployment-evidence/f3a14e652/private-preservation.json').read_text())['files'].items():
  p=pathlib.Path(n);assert hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'] and stat.S_IMODE(p.stat().st_mode)==v['mode'],'PROTECTED_FILE_CHANGED'
def health():
 with urllib.request.urlopen('http://127.0.0.1:8080/api/health',timeout=5) as f:h=json.load(f)
 assert h['coreOk'] and h['systemOk'] and h['source']['gitHead']==target and not h['source']['dirty'];return h
assert run('git','rev-parse','HEAD')==target and not run('git','status','--porcelain');assert not (out/(mode+'-web.json')).exists(),'ROUNDTRIP_STAGE_ALREADY_RECORDED';health();protected();before=apps()
current=out/'current-web.tar.gz';previous=out/'previous-web.tar.gz'
assert hashlib.sha256(previous.read_bytes()).hexdigest()=='9eb715c0e843c03d858450a145f2aa33e2f78ef71669b8089b77f3c46b1f30f4'
if mode=='rollback':
 assert not current.exists();run('bash','scripts/deployment/web-artifacts.sh','pack',str(current))
archive=previous if mode=='rollback' else current
run('bash','scripts/deployment/web-artifacts.sh','install',str(archive))
expected={}
with tarfile.open(archive,'r:gz') as t:
 for m in t.getmembers():
  if m.isfile():
   f=t.extractfile(m);assert f;expected[m.name]=hashlib.sha256(f.read()).hexdigest()
actual={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for root in ['frontend/build','ui/dist'] for p in (r/root).rglob('*') if p.is_file()}
assert actual==expected,'INSTALLED_WEB_BYTES_DIFFER';assert apps()==before,'PROCESS_OWNER_CHANGED';health();protected()
result={'mode':mode,'backendSource':target,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':actual,'processesUnchanged':True,'protectedFilesUnchanged':True,'dataReset':False,'backendRestart':False}
(out/(mode+'-web.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='files'}|{'filesVerified':len(actual)}))
