# Prepared RPC publication policy decision

Not applied. Current source main8235ffb62 deliberately denies raw transaction broadcast;
tests/frontend/security/rpc-proxy-safety.test.ts positively requires that denial.
Actual public production-wallet run fails after gas/reserve funding: eth_sendRawTransaction
gets403 and the100USDC reserve-to-Account operation never commits. Test trace and
RPC response are in ../public-financial-relative/. Reserve faucet success is not payment success.

Recommended exact scope: permit eth_sendRawTransaction in the one shared RPC method
allowlist, keeping signing/unlocked-account/admin methods denied. Existing fixed upstream,
256KiB request,128-call batch,8MiB response and timeout guards remain unchanged.
Node validation remains authoritative for raw signature, nonce, chain and funds. This
permits public broadcast traffic; it is an explicit widening from the existing read-only
policy, not a correction to TLS, authentication or the transport route.

The proposed production diff is reviewable here. Before publication it still requires
updated focused signed-wire allow/unsigned-admin deny tests, actual node-backed relay
regression, full unchanged check and the same public reserve/payment/reload test.
No unsafe-proxy flag, server credential sent to browser, alternate RPC fallback or
second signing implementation is proposed. No mainnet funds/deployment is authorized.

Alternative: keep this public proxy read-only, leaving browser-signed onchain flows
blocked until an independently configured broadcasting service is explicitly selected.
The current frontend manifest points to this exact proxy, so retries cannot fix it.
