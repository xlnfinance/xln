#!/bin/bash
set -euo pipefail
if PATH="/root/.bun/bin:/usr/bin:/bin" bash -ec 'source /root/xln-deployment-evidence/bun-1.4.0/start-common.candidate.sh; xln_require_pinned_bun /root/xln'; then
  echo OLD_BUN_WRONGLY_ACCEPTED >&2
  exit 1
fi
PATH="/root/.local/share/xln/toolchains/bun-1.4.0:/usr/bin:/bin" bash -ec 'source /root/xln-deployment-evidence/bun-1.4.0/start-common.candidate.sh; xln_require_pinned_bun /root/xln; "$XLN_START_BUN" --version'
echo PINNED_SELECTION_PASS
