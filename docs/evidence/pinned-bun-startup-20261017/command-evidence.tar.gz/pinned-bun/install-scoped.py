import pathlib,subprocess,hashlib,zipfile,json,os,time
out=pathlib.Path('/root/xln-deployment-evidence/bun-1.4.0');out.mkdir(parents=True,exist_ok=True)
global_bun=pathlib.Path('/root/.bun/bin/bun');old_hash=hashlib.sha256(global_bun.read_bytes()).hexdigest()
archive=out/'bun-linux-x64.zip';url='https://github.com/oven-sh/bun/releases/download/bun-v1.4.0/bun-linux-x64.zip';expected='2d03fb5fb83ac8b567aca0a281b2ce1a1a19d488f56c2968d88c3f25e92fe452'
if not archive.exists():subprocess.run(['curl','--fail','--location','--silent','--show-error','--connect-timeout','5','--max-time','40',url,'-o',str(archive)],check=True,timeout=45)
assert hashlib.sha256(archive.read_bytes()).hexdigest()==expected,'OFFICIAL_ARTIFACT_DIGEST_MISMATCH'
with zipfile.ZipFile(archive) as z:
 assert z.namelist()==['bun-linux-x64/','bun-linux-x64/bun'],'UNEXPECTED_ARCHIVE_PATHS';data=z.read('bun-linux-x64/bun')
root=pathlib.Path('/root/.local/share/xln/toolchains/bun-1.4.0');root.mkdir(parents=True,exist_ok=True);binary=root/'bun'
if binary.exists():assert binary.read_bytes()==data,'EXISTING_TOOLCHAIN_BYTES_DIFFER'
else:
 with binary.open('xb') as f:f.write(data)
 binary.chmod(0o755)
version=subprocess.check_output([str(binary),'--version'],text=True,timeout=5).strip();assert version=='1.4.0';assert hashlib.sha256(global_bun.read_bytes()).hexdigest()==old_hash,'GLOBAL_BUN_CHANGED'
result={'url':url,'archiveSha256':expected,'binaryPath':str(binary),'binarySha256':hashlib.sha256(data).hexdigest(),'version':version,'globalBunUnchanged':True,'globalBunVersion':subprocess.check_output([str(global_bun),'--version'],text=True,timeout=5).strip(),'servicesChanged':False};(out/'artifact.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
