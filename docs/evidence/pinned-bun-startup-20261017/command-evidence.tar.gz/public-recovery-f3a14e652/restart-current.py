import pathlib,json,subprocess,hashlib,stat,urllib.request,time,os
r=pathlib.Path('/root/xln');out=pathlib.Path('/root/xln-deployment-evidence/f3a14e652/recovery');base=out.parent
started=time.monotonic();steps=[]
def step(name):
 record={'step':name,'elapsedSeconds':round(time.monotonic()-started,3),'at':int(time.time()*1000)};steps.append(record);(out/'restart-progress.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(record),flush=True)
def run(args,timeout=10):return subprocess.check_output(args,cwd=r,text=True,timeout=timeout)
def health():
 with urllib.request.urlopen('http://127.0.0.1:8080/api/health',timeout=2) as f:return json.load(f)
def pm2():return json.loads(run(['pm2','jlist']))
def protected():
 for n,v in json.loads((base/'private-preservation.json').read_text())['files'].items():
  p=pathlib.Path(n);assert hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'] and stat.S_IMODE(p.stat().st_mode)==v['mode'],'PROTECTED_FILE_CHANGED'
assert run(['git','rev-parse','HEAD']).strip()=='f3a14e6528415c7c98da7865eb6492becb8c1c61';assert not run(['git','status','--porcelain=v1','--untracked-files=all'])
assert not pathlib.Path('/var/lib/xln/rdb/core/.mesh-reset-once').exists(),'RESET_MARKER_PRESENT'
assert pathlib.Path('/var/lib/xln/rdb/core/prod-mesh/jurisdictions.json').is_file(),'CURRENT_JURISDICTIONS_MISSING'
protected();rows=pm2();server=next(x for x in rows if x['name']=='xln-server');e=server['pm2_env'];assert e['status']=='online' and e['pm_cwd']==str(r) and e['pm_exec_path']==str(r/'scripts/operations/start-server.sh')
assert server['pid']==json.loads((base/'runtime-start.json').read_text())['managedOwners'][next(i for i,x in enumerate(json.loads((base/'runtime-start.json').read_text())['managedOwners']) if x['name']=='xln-server')]['pid'],'SERVER_OWNER_CHANGED'
unrelated={x['name']:{'pid':x['pid'],'status':x['pm2_env']['status']} for x in rows if x['name']!='xln-server'}
h=health();assert h['coreOk'] and h['systemOk'];assert h['marketMaker']['quiescence']=={'accountMempoolTxs':0,'pendingAccountFrames':0,'pendingRuntimeWork':0}
(out/'preflight-before.json').write_bytes((out/'before.json').read_bytes());print(run(['bun',str(out/'snapshot.ts'),'before']),flush=True);step('current-state-snapshot')
roots=[pathlib.Path('/var/lib/xln/rdb/core/prod-mesh'),pathlib.Path('/var/lib/xln/rdb/core/prod-main')]
for p in roots:assert p.is_dir() and not p.is_symlink()
print(run(['pm2','stop','xln-server'],15),flush=True);step('server-stopped')
for p in roots:
 result=subprocess.run(['lsof','-t','+D',str(p)],capture_output=True,text=True,timeout=8);assert result.returncode in [0,1] and not result.stdout.strip(),'CURRENT_STORE_STILL_OPEN'
step('current-stores-zero-handles')
backup=out/'current-format-before-restart.tar.gz';assert not backup.exists()
subprocess.run(['tar','-czf',str(backup),'-C','/var/lib/xln/rdb/core','prod-mesh','prod-main'],check=True,timeout=10);backup.chmod(0o600)
backupProof={'path':str(backup),'bytes':backup.stat().st_size,'sha256':hashlib.sha256(backup.read_bytes()).hexdigest()};(out/'current-backup.json').write_text(json.dumps(backupProof,indent=2)+'\n');step('current-format-backup')
assert not pathlib.Path('/var/lib/xln/rdb/core/.mesh-reset-once').exists();assert pathlib.Path('/var/lib/xln/rdb/core/prod-mesh/jurisdictions.json').is_file()
print(run(['pm2','restart','xln-server'],10),flush=True);step('server-restarted-preserve-current-state')
for x in pm2():
 if x['name'] in unrelated:assert unrelated[x['name']]=={'pid':x['pid'],'status':x['pm2_env']['status']},'UNRELATED_OWNER_CHANGED'
while time.monotonic()-started<53:
 try:
  h=health()
  if h['coreOk'] and h['systemOk']:break
 except (OSError,ValueError):pass
 time.sleep(.5)
else:raise RuntimeError('CURRENT_RECOVERY_NOT_READY_WITHIN_OBSERVATION_BUDGET')
step('current-recovery-ready');print(run(['bun',str(out/'snapshot.ts'),'after'],6),flush=True);protected();step('exact-committed-frames-accounts-and-protected-files-preserved')
result={'sourceSha':'f3a14e6528415c7c98da7865eb6492becb8c1c61','elapsedSeconds':round(time.monotonic()-started,3),'dataReset':False,'backup':backupProof,'unrelatedProcessesUnchanged':True,'protectedFilesUnchanged':True,'stages':steps};(out/'restart-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
