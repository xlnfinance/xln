import subprocess,json
rows=json.loads(subprocess.check_output(['pm2','jlist'],text=True))
p=next(p for p in rows if p['name']=='xln-server');e=p['pm2_env']
# Current orchestrator shutdown: HTTP drain, child quiesce, inter-round pause,
# then the child's graceful deadline and bounded forced-termination deadline.
quiesce=max(1000,int(e.get('XLN_CHILD_SHUTDOWN_QUIESCE_MS',5000)))
required=5000+quiesce+150+2*20000
result={'name':p['name'],'pid':p['pid'],'treekill':e.get('treekill'),'killTimeoutMs':e.get('kill_timeout'),'requiredCurrentStopBudgetMs':required}
print(json.dumps(result),flush=True)
assert e.get('treekill') is False,'PM2_SIGNALS_CHILDREN_BEFORE_ORCHESTRATOR_QUIESCE'
assert isinstance(e.get('kill_timeout'),int) and e['kill_timeout']>=required,'PM2_KILL_TIMEOUT_PREEMPTS_CURRENT_SHUTDOWN_BUDGET'
assert e['status']=='online','PM2_SERVER_NOT_ONLINE'
print('CURRENT_ORCHESTRATOR_SUPERVISION_OK')
