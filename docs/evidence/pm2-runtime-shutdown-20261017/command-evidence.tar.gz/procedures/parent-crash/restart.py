import pathlib,json,subprocess,hashlib,stat,urllib.request,time,os
r=pathlib.Path('/root/xln');base=pathlib.Path('/root/xln-deployment-evidence/33260898b');out=base/'pm2-parent-crash';target='33260898b968f1b6c70ea0b702048f1997598466';pin='/root/.local/share/xln/toolchains/bun-1.4.0/bun';started=time.monotonic();steps=[]
def step(name):
 record={'step':name,'elapsedSeconds':round(time.monotonic()-started,3),'at':int(time.time()*1000)};steps.append(record);(out/'restart-progress.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(record),flush=True)
def run(args,timeout=10):return subprocess.check_output(args,cwd=r,text=True,timeout=timeout)
def health():
 with urllib.request.urlopen('http://127.0.0.1:8080/api/health',timeout=2) as f:return json.load(f)
def pm2():return json.loads(run(['pm2','jlist']))
def protected():
 for n,v in json.loads(pathlib.Path('/root/xln-deployment-evidence/f3a14e652/private-preservation.json').read_text())['files'].items():
  p=pathlib.Path(n);assert hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'] and stat.S_IMODE(p.stat().st_mode)==v['mode'],'PROTECTED_FILE_CHANGED'
assert run(['git','rev-parse','HEAD']).strip()==target;assert not run(['git','status','--porcelain=v1','--untracked-files=all']);assert not (out/'restart-progress.json').exists(),'DRILL_ALREADY_STARTED'
assert not pathlib.Path('/var/lib/xln/rdb/core/.mesh-reset-once').exists();protected()
rows=pm2();server=next(x for x in rows if x['name']=='xln-server');e=server['pm2_env'];assert e['status']=='online' and e['pm_cwd']==str(r) and e['pm_exec_path']==str(r/'scripts/operations/start-server.sh')
assert server['pid']==1012666,'SERVER_OWNER_CHANGED';assert os.readlink('/proc/'+str(server['pid'])+'/exe')==pin;assert e['treekill'] is False and e.get('kill_timeout')==60000,'BASELINE_POLICY_CHANGED'
private=out/'private-pm2-before.json';fd=os.open(private,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w') as f:json.dump(rows,f)
unrelated={x['name']:{'pid':x['pid'],'status':x['pm2_env']['status']} for x in rows if x['name']!='xln-server'}
h=health();assert h['coreOk'] and h['systemOk'];assert h['marketMaker']['quiescence']=={'accountMempoolTxs':0,'pendingAccountFrames':0,'pendingRuntimeWork':0}
print(run([pin,str(out/'snapshot.ts'),'before']),flush=True);step('current-state-snapshot')
errorlog=pathlib.Path(e['pm_err_log_path']);logstat=errorlog.stat();offset=logstat.st_size
(out/'log-before.json').write_text(json.dumps({'path':str(errorlog),'inode':logstat.st_ino,'offset':offset})+'\n')
def identity(pid):
 try:
  value=pathlib.Path('/proc/'+str(pid)+'/stat').read_text();fields=value[value.rindex(')')+2:].split();return {'parent':int(fields[1]),'startTicks':fields[19]}
 except FileNotFoundError:return None
allProcesses={int(p.name):identity(int(p.name)) for p in pathlib.Path('/proc').iterdir() if p.name.isdigit()}
owned={server['pid']}
while True:
 expanded=owned|{pid for pid,v in allProcesses.items() if v and v['parent'] in owned}
 if expanded==owned:break
 owned=expanded
assert len(owned)==7,'UNEXPECTED_RUNTIME_PROCESS_TREE'
oldProcesses={pid:allProcesses[pid] for pid in owned}
assert identity(server['pid'])==oldProcesses[server['pid']],'PARENT_IDENTITY_CHANGED'
(out/'old-processes.json').write_text(json.dumps(oldProcesses,indent=2)+'\n')
os.kill(server['pid'],9);step('exact-orchestrator-sigkill')
while time.monotonic()-started<53:
 try:
  h=health()
  if h['coreOk'] and h['systemOk']:break
 except (OSError,ValueError):pass
 time.sleep(.5)
else:raise RuntimeError('PARENT_ONLY_RESTART_NOT_READY_WITHIN_OBSERVATION_BUDGET')
step('current-recovery-ready');rows=pm2();now=next(x for x in rows if x['name']=='xln-server');assert now['pid']!=server['pid'],'SUPERVISOR_DID_NOT_REPLACE_PARENT'
for x in rows:
 if x['name'] in unrelated:assert unrelated[x['name']]=={'pid':x['pid'],'status':x['pm2_env']['status']},'UNRELATED_OWNER_CHANGED'
for pid,v in oldProcesses.items():assert identity(pid)!=v,('OLD_MANAGED_PROCESS_STILL_ALIVE',pid)
protected();assert h['source']['gitHead']==target and not h['source']['dirty']
assert errorlog.stat().st_ino==logstat.st_ino and errorlog.stat().st_size>=offset,'ERROR_LOG_ROTATED_DURING_DRILL'
with errorlog.open('rb') as f:f.seek(offset);delta=f.read()
log=out/'private-shutdown-error.log';log.write_bytes(delta);log.chmod(0o600)
text=delta.decode(errors='replace');markers={n:text.count(n) for n in ['NAPI FATAL ERROR','Bun has crashed','panic:','shutdown failed:']}
result={'sha':target,'elapsedSeconds':round(time.monotonic()-started,3),'managedRecoveryDurationMs':h['reset']['completedAt']-h['reset']['startedAt'],'dataReset':False,'fault':'SIGKILL exact orchestrator parent','oldProcessIdentitiesGone':list(oldProcesses),'newServerPid':now['pid'],'treekill':now['pm2_env']['treekill'],'killTimeoutMs':now['pm2_env']['kill_timeout'],'protectedFilesUnchanged':True,'unrelatedProcessesUnchanged':True,'failureMarkers':markers,'errorDeltaBytes':len(delta),'errorDeltaSha256':hashlib.sha256(delta).hexdigest(),'stages':steps}
(out/'restart-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);assert not any(markers.values()),'PARENT_CRASH_RECOVERY_DIVERGENCE'
