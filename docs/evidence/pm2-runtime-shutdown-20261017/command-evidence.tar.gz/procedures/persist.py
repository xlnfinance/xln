import json,pathlib,subprocess,shutil,hashlib
base=pathlib.Path('/root/xln-deployment-evidence/33260898b');out=base/'pm2-shutdown';old=json.loads((out/'private-pm2-before.json').read_text());rows=json.loads(subprocess.check_output(['pm2','jlist'],text=True));before=next(x for x in old if x['name']=='xln-server')['pm2_env'];server=next(x for x in rows if x['name']=='xln-server');e=server['pm2_env'];assert server['pid']==json.loads((base/'pm2-parent-crash/restart-result.json').read_text())['newServerPid'];assert e['treekill'] is False and e['kill_timeout']==60000
assert e['env']==before['env'],'SERVICE_ENVIRONMENT_CHANGED'
for k in ['pm_cwd','pm_exec_path','args','PATH','max_memory_restart','autorestart','restart_delay','exec_interpreter','namespace','uid','gid']:assert e.get(k)==before.get(k),('UNREQUESTED_PROCESS_CONFIGURATION_CHANGED',k)
for x in rows:
 if x['name']=='xln-server':continue
 prior=next(y for y in old if y['name']==x['name']);assert x['pid']==prior['pid'] and x['pm2_env']['status']==prior['pm2_env']['status'],'UNRELATED_OWNER_CHANGED'
p=pathlib.Path('/root/.pm2/dump.pm2');backup=out/'private-pm2-dump-before.json';assert p.is_file() and not p.is_symlink() and not backup.exists();shutil.copy2(p,backup);backup.chmod(0o600)
subprocess.run(['pm2','save'],check=True,timeout=10);saved=next(x for x in json.loads(p.read_text()) if x['name']=='xln-server');assert saved['treekill'] is False and saved['kill_timeout']==60000
result={'treekill':False,'killTimeoutMs':60000,'serviceEnvironmentUnchanged':True,'otherConfigurationUnchanged':True,'unrelatedProcessesUnchanged':True,'previousDumpSha256':hashlib.sha256(backup.read_bytes()).hexdigest(),'savedDumpSha256':hashlib.sha256(p.read_bytes()).hexdigest()};(out/'persistent-supervision.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
