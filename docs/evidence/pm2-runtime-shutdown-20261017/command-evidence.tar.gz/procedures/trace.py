import pathlib,subprocess,json,hashlib
root=pathlib.Path('/usr/lib/node_modules/pm2');ps=json.loads(subprocess.check_output(['pm2','jlist'],text=True));p=next(p for p in ps if p['name']=='xln-server');e=p['pm2_env'];print(json.dumps({'name':p['name'],'pid':p['pid'],'treekill':e.get('treekill'),'kill_timeout':e.get('kill_timeout'),'kill_retry_time':e.get('kill_retry_time')}))
for path in [root/'lib/God/Methods.js',root/'constants.js',root/'lib/binaries/CLI.js']:
 lines=path.read_text().splitlines();print(json.dumps({'source':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}))
 selected=set()
 for i,line in enumerate(lines):
  if any(k in line for k in ['treekill','kill-timeout','KILL_TIMEOUT','KILL_SIGNAL']):selected.update(range(max(0,i-2),min(len(lines),i+4)))
 for i in sorted(selected):print(str(path)+':'+str(i+1)+':'+lines[i])
