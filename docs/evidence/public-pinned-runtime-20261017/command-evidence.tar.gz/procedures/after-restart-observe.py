import pathlib,json,subprocess,time,urllib.request,hashlib,stat,os
out=pathlib.Path('/root/xln-deployment-evidence/33260898b');r=pathlib.Path('/root/xln');start=time.monotonic();target='33260898b968f1b6c70ea0b702048f1997598466'
while time.monotonic()-start<53:
 try:
  with urllib.request.urlopen('http://127.0.0.1:8080/api/health',timeout=2) as f:h=json.load(f)
  if h['coreOk'] and h['systemOk']:break
 except (OSError,ValueError):pass
 time.sleep(.5)
else:raise RuntimeError('PINNED_RUNTIME_NOT_READY_WITHIN_BOUNDED_OBSERVATION')
assert h['source']['gitHead']==target and not h['source']['dirty'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==target
rows=json.loads(subprocess.check_output(['pm2','jlist'],text=True));before=json.loads((out/'owners-before.json').read_text())
for p in rows:
 if p['name'] not in ['xln-server','xln-watchtower']:assert before[p['name']]=={'pid':p['pid'],'status':p['pm2_env']['status']},'UNRELATED_OWNER_CHANGED'
for n,v in json.loads(pathlib.Path('/root/xln-deployment-evidence/f3a14e652/private-preservation.json').read_text())['files'].items():
 p=pathlib.Path(n);assert hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'] and stat.S_IMODE(p.stat().st_mode)==v['mode'],'PROTECTED_FILE_CHANGED'
processes={}
for d in pathlib.Path('/proc').iterdir():
 if not d.name.isdigit():continue
 try:
  status=(d/'status').read_text();ppid=int(next(x.split()[1] for x in status.splitlines() if x.startswith('PPid:')));exe=os.readlink(d/'exe');processes[int(d.name)]={'pid':int(d.name),'ppid':ppid,'executable':exe}
 except (OSError,StopIteration):pass
owned={p['pid'] for p in rows if p['name'] in ['xln-server','xln-watchtower']};assert len(owned)==2 and 0 not in owned
while True:
 descendants={pid for pid,p in processes.items() if p['ppid'] in owned};new=owned|descendants
 if new==owned:break
 owned=new
buns=[processes[p] for p in sorted(owned) if p in processes and pathlib.Path(processes[p]['executable']).name=='bun']
required={'core/orchestrator/orchestrator.ts':1,'core/orchestrator/hub-node.ts':3,'core/orchestrator/mm-node.ts':1,'core/watchtower/standalone-server.ts':1,'custody/server.ts':1,'core/api/server/index.ts':1}
actual={k:0 for k in required}
for p in buns:
 args=(pathlib.Path('/proc')/str(p['pid'])/'cmdline').read_bytes().split(b'\0')
 for k in required:
  if k.encode() in args:actual[k]+=1
assert actual==required,('REQUIRED_MANAGED_PROCESSES_MISSING',actual)
for p in buns:assert p['executable']=='/root/.local/share/xln/toolchains/bun-1.4.0/bun','CHILD_RUNTIME_NOT_PINNED'
assert subprocess.check_output(['/root/.bun/bin/bun','--version'],text=True).strip()=='1.3.14','GLOBAL_RUNTIME_CHANGED'
result={'sha':target,'health':h,'ownedBunProcesses':buns,'unrelatedProcessesUnchanged':True,'protectedFilesUnchanged':True,'globalBunUnchanged':True,'observationSeconds':round(time.monotonic()-start,3),'managedRecoveryDurationMs':h['reset']['completedAt']-h['reset']['startedAt'],'at':int(time.time()*1000)}
(out/'after-restart-ready.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='health'}),flush=True)
