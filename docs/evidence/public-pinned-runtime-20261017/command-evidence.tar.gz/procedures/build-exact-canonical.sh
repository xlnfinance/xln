set -euo pipefail
REPO_ROOT=/Users/zigota/xln
SCRIPT_DIR="$REPO_ROOT/scripts/deployment"
cd "$REPO_ROOT"
source "$REPO_ROOT/scripts/lib/start-common.sh"
ensure_clean_worktree_for_remote_deploy() {
  bun "$REPO_ROOT/tools/release-snapshot/assert-clean.ts" "$REPO_ROOT"
}

ensure_committed_contract_artifacts() {
  local changes
  changes="$(git status --short -- frontend/static/contracts jurisdictions/artifacts jurisdictions/typechain-types)"
  if [ -n "$changes" ]; then
    echo "CONTRACT_ARTIFACTS_NOT_COMMITTED" >&2
    printf '%s\n' "$changes" >&2
    exit 1
  fi
}

build_hosted_wallet() {
  (
    cd "$REPO_ROOT/ui"
    bun install --frozen-lockfile
    NODE_ENV=production XLN_UI_STACK_ORIGIN= bun run build:hosted
  )
}

build_remote_frontend_archive() {
  xln_require_pinned_bun "$REPO_ROOT"
  local deploy_build_number
  deploy_build_number="$(date -u +%Y%m%d%H%M%S)-$(git rev-parse --short HEAD)"
  echo "[deploy] building production frontend locally: $deploy_build_number"
  bun install --frozen-lockfile
  ./scripts/sync-contract-artifacts.sh
  ensure_committed_contract_artifacts
  ./scripts/build-runtime.sh
  (
    cd frontend
    bun install --frozen-lockfile
    XLN_BUILD_NUMBER="$deploy_build_number" bun run build
  )
  build_hosted_wallet
  PREBUILT_FRONTEND_ARCHIVE="$(mktemp "${TMPDIR:-/tmp}/xln-frontend-build.XXXXXX.tar.gz")"
  bash "$SCRIPT_DIR/web-artifacts.sh" pack "$PREBUILT_FRONTEND_ARCHIVE"
}

ensure_clean_worktree_for_remote_deploy
[ "$(git rev-parse HEAD)" = 33260898b968f1b6c70ea0b702048f1997598466 ]
build_remote_frontend_archive
ensure_clean_worktree_for_remote_deploy
cp "$PREBUILT_FRONTEND_ARCHIVE" /Users/zigota/agent-jobs/xln-mainnet-autonomy-20261017/operator-33260898b/web.tar.gz
rm -f "$PREBUILT_FRONTEND_ARCHIVE"
