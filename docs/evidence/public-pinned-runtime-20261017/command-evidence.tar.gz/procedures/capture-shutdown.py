import pathlib,json,re,hashlib
out=pathlib.Path('/root/xln-deployment-evidence/33260898b');results=[]
for name,offset in json.loads((out/'log-offsets.json').read_text()).items():
 p=pathlib.Path(name);assert p.stat().st_size>=offset,'LOG_ROTATED_DURING_OBSERVATION'
 with p.open('rb') as f:f.seek(offset);data=f.read()
 saved=out/(p.name+'.since-transition');saved.write_bytes(data);saved.chmod(0o600)
 text=data.decode(errors='replace');results.append({'path':name,'offset':offset,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'napiFatalReports':text.count('NAPI FATAL ERROR'),'bunVersions':re.findall(r'Bun v([0-9.]+)',text),'panicCount':text.count('panic('),'savedPrivate':str(saved)})
(out/'shutdown-observation.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))
