import pathlib,json,subprocess,shutil,hashlib
out=pathlib.Path('/root/xln-deployment-evidence/33260898b');ready=json.loads((out/'ready.json').read_text());before=json.loads((out/'owners-before.json').read_text());rows=json.loads(subprocess.check_output(['pm2','jlist'],text=True))
for row in rows:
 if row['name'] in ['xln-server','xln-watchtower']:
  assert row['pid'] in [p['pid'] for p in ready['ownedBunProcesses']];assert row['pm2_env']['PATH'].split(':')[0]=='/root/.local/share/xln/toolchains/bun-1.4.0'
 else:assert before[row['name']]=={'pid':row['pid'],'status':row['pm2_env']['status']}
p=pathlib.Path('/root/.pm2/dump.pm2');assert p.is_file() and not p.is_symlink();backup=out/'private-pm2-dump-before.json';assert not backup.exists();shutil.copy2(p,backup);backup.chmod(0o600)
subprocess.run(['pm2','save'],check=True,timeout=10)
saved=json.loads(p.read_text())
for name in ['xln-server','xln-watchtower']:
 e=next(e for e in saved if e['name']==name);assert e['PATH'].split(':')[0]=='/root/.local/share/xln/toolchains/bun-1.4.0'
record={'savedOwnedNames':['xln-server','xln-watchtower'],'previousDumpSha256':hashlib.sha256(backup.read_bytes()).hexdigest(),'currentDumpSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'unrelatedOwnersUnchanged':True};(out/'persistent-runtime.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
