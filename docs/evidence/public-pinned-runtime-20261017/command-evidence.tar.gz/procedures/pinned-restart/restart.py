import pathlib,json,subprocess,hashlib,stat,urllib.request,time,os
r=pathlib.Path('/root/xln');base=pathlib.Path('/root/xln-deployment-evidence/33260898b');out=base/'pinned-restart';target='33260898b968f1b6c70ea0b702048f1997598466';pin='/root/.local/share/xln/toolchains/bun-1.4.0/bun';started=time.monotonic();steps=[]
def step(name):
 record={'step':name,'elapsedSeconds':round(time.monotonic()-started,3),'at':int(time.time()*1000)};steps.append(record);(out/'restart-progress.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(record),flush=True)
def run(args,timeout=10):return subprocess.check_output(args,cwd=r,text=True,timeout=timeout)
def health():
 with urllib.request.urlopen('http://127.0.0.1:8080/api/health',timeout=2) as f:return json.load(f)
def pm2():return json.loads(run(['pm2','jlist']))
def protected():
 for n,v in json.loads(pathlib.Path('/root/xln-deployment-evidence/f3a14e652/private-preservation.json').read_text())['files'].items():
  p=pathlib.Path(n);assert hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'] and stat.S_IMODE(p.stat().st_mode)==v['mode'],'PROTECTED_FILE_CHANGED'
assert run(['git','rev-parse','HEAD']).strip()==target;assert not run(['git','status','--porcelain=v1','--untracked-files=all']);assert not (out/'restart-progress.json').exists(),'DRILL_ALREADY_STARTED'
assert not pathlib.Path('/var/lib/xln/rdb/core/.mesh-reset-once').exists();assert pathlib.Path('/var/lib/xln/rdb/core/prod-mesh/jurisdictions.json').is_file();protected()
rows=pm2();server=next(x for x in rows if x['name']=='xln-server');e=server['pm2_env'];assert e['status']=='online' and e['pm_cwd']==str(r) and e['pm_exec_path']==str(r/'scripts/operations/start-server.sh')
assert server['pid']==json.loads((base/'started.json').read_text())['owners']['xln-server']['pid'],'SERVER_OWNER_CHANGED';assert os.readlink('/proc/'+str(server['pid'])+'/exe')==pin
unrelated={x['name']:{'pid':x['pid'],'status':x['pm2_env']['status']} for x in rows if x['name']!='xln-server'}
h=health();assert h['coreOk'] and h['systemOk'];assert h['marketMaker']['quiescence']=={'accountMempoolTxs':0,'pendingAccountFrames':0,'pendingRuntimeWork':0}
print(run([pin,str(out/'snapshot.ts'),'before']),flush=True);step('current-state-snapshot')
errorlog=pathlib.Path(e['pm_err_log_path']);logstat=errorlog.stat();offset=logstat.st_size
(out/'log-before.json').write_text(json.dumps({'path':str(errorlog),'inode':logstat.st_ino,'offset':offset})+'\n')
roots=[pathlib.Path('/var/lib/xln/rdb/core/prod-mesh'),pathlib.Path('/var/lib/xln/rdb/core/prod-main')]
for p in roots:assert p.is_dir() and not p.is_symlink()
print(run(['pm2','stop','xln-server'],15),flush=True);step('server-stopped')
for p in roots:
 result=subprocess.run(['lsof','-t','+D',str(p)],capture_output=True,text=True,timeout=8);assert result.returncode in [0,1] and not result.stdout.strip(),'CURRENT_STORE_STILL_OPEN'
step('current-stores-zero-handles');backup=out/'current-before-restart.tar.gz';assert not backup.exists()
subprocess.run(['tar','-czf',str(backup),'-C','/var/lib/xln/rdb/core','prod-mesh','prod-main'],check=True,timeout=10);backup.chmod(0o600)
proof={'path':str(backup),'bytes':backup.stat().st_size,'sha256':hashlib.sha256(backup.read_bytes()).hexdigest()};(out/'current-backup.json').write_text(json.dumps(proof,indent=2)+'\n');step('current-format-backup')
print(run(['pm2','restart','xln-server'],10),flush=True);step('server-restarted-preserve-current-state')
for x in pm2():
 if x['name'] in unrelated:assert unrelated[x['name']]=={'pid':x['pid'],'status':x['pm2_env']['status']},'UNRELATED_OWNER_CHANGED'
while time.monotonic()-started<53:
 try:
  h=health()
  if h['coreOk'] and h['systemOk']:break
 except (OSError,ValueError):pass
 time.sleep(.5)
else:raise RuntimeError('PINNED_RESTART_NOT_READY_WITHIN_OBSERVATION_BUDGET')
step('current-recovery-ready');protected();assert h['source']['gitHead']==target and not h['source']['dirty']
assert errorlog.stat().st_ino==logstat.st_ino and errorlog.stat().st_size>=offset,'ERROR_LOG_ROTATED_DURING_DRILL'
with errorlog.open('rb') as f:f.seek(offset);delta=f.read()
log=out/'private-shutdown-error.log';log.write_bytes(delta);log.chmod(0o600)
text=delta.decode(errors='replace');fatal={n:text.count(n) for n in ['NAPI FATAL ERROR','Bun has crashed','panic:']}
result={'sha':target,'elapsedSeconds':round(time.monotonic()-started,3),'managedRecoveryDurationMs':h['reset']['completedAt']-h['reset']['startedAt'],'dataReset':False,'backup':proof,'protectedFilesUnchanged':True,'unrelatedProcessesUnchanged':True,'fatalMarkers':fatal,'errorDeltaBytes':len(delta),'errorDeltaSha256':hashlib.sha256(delta).hexdigest(),'stages':steps}
(out/'restart-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);assert not any(fatal.values()),'PINNED_BUN_SHUTDOWN_FATAL_REPRODUCED'
