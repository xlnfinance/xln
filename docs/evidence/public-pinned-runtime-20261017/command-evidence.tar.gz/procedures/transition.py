import pathlib,subprocess,json,hashlib,stat,os,time,urllib.request,sys,tarfile
r=pathlib.Path('/root/xln');out=pathlib.Path('/root/xln-deployment-evidence/33260898b');old=pathlib.Path('/root/xln-deployment-evidence/f3a14e652')
target='33260898b968f1b6c70ea0b702048f1997598466';prior='f3a14e6528415c7c98da7865eb6492becb8c1c61';pin='/root/.local/share/xln/toolchains/bun-1.4.0/bun';owned=['xln-server','xln-watchtower'];phase=sys.argv[1];started=time.monotonic()
def run(args,timeout=10,env=None):return subprocess.check_output(args,cwd=r,text=True,timeout=timeout,env=env)
def save(name,data): (out/name).write_text(json.dumps(data,indent=2)+'\n')
def rows():return json.loads(run(['pm2','jlist']))
def safe(ps):return {x['name']:{'pid':x['pid'],'status':x['pm2_env']['status']} for x in ps}
def protected():
 for n,v in json.loads((old/'private-preservation.json').read_text())['files'].items():
  p=pathlib.Path(n);assert hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'] and stat.S_IMODE(p.stat().st_mode)==v['mode'],'PROTECTED_FILE_CHANGED'
def clean(expected):
 assert run(['git','rev-parse','HEAD']).strip()==expected,'SOURCE_HEAD_CHANGED'
 assert not run(['git','status','--porcelain=v1','--untracked-files=all']),'SOURCE_DIRTY'
 assert not pathlib.Path('/var/lib/xln/rdb/core/.mesh-reset-once').exists(),'RESET_MARKER_PRESENT'
def unchanged_unrelated(ps,baseline):
 for x in ps:
  if x['name'] not in owned:assert safe([x])[x['name']]==baseline[x['name']],'UNRELATED_PROCESS_CHANGED'
protected();assert run([pin,'--version']).strip()=='1.4.0';assert hashlib.sha256(pathlib.Path(pin).read_bytes()).hexdigest()=='33d56b070be6a9e3da0ab013038b43d1645d0534ca811ecdba4472599117eb4b'
if phase=='stop':
 clean(prior);assert not (out/'stopped.json').exists(),'STOP_ALREADY_RECORDED'
 ps=rows();baseline=safe(ps)
 for name in owned:
  p=next(p for p in ps if p['name']==name);e=p['pm2_env'];assert e['status']=='online' and e['pm_cwd']==str(r);assert e['pm_exec_path']==str(r/'scripts/operations'/('start-server.sh' if name=='xln-server' else 'start-watchtower.sh'))
  assert not any(k.startswith(('XLN_STAND_','XLN_LOCAL_TEST_LEASE_')) for k in e.get('env',{})),'PERSISTED_TEST_OWNERSHIP_PRESENT'
 with urllib.request.urlopen('http://127.0.0.1:8080/api/health',timeout=3) as f:h=json.load(f)
 assert h['coreOk'] and h['systemOk'];assert h['marketMaker']['quiescence']=={'accountMempoolTxs':0,'pendingAccountFrames':0,'pendingRuntimeWork':0}
 print(run([pin,str(out/'snapshot.ts'),'before'],10),flush=True)
 save('owners-before.json',baseline)
 raw=json.dumps(ps);private=out/'private-pm2-before.json';fd=os.open(private,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:f.write(raw)
 logs={}
 for p in ps:
  if p['name'] in owned:
   for k in ['pm_err_log_path','pm_out_log_path']:
    path=pathlib.Path(p['pm2_env'][k]);logs[str(path)]=path.stat().st_size if path.exists() else 0
 save('log-offsets.json',logs)
 print(run(['pm2','stop',*owned],20),flush=True)
 roots=['core/prod-main','core/prod-mesh','watchtower/prod-main','custody/prod'];existing=[]
 for n in roots:
  p=pathlib.Path('/var/lib/xln/rdb')/n
  if not p.exists():continue
  assert p.is_dir() and not p.is_symlink();existing.append(n)
  result=subprocess.run(['lsof','-t','+D',str(p)],capture_output=True,text=True,timeout=8);assert result.returncode in [0,1] and not result.stdout.strip(),'CURRENT_STORE_STILL_OPEN'
 backup=out/'current-before-toolchain.tar.gz';assert not backup.exists()
 subprocess.run(['tar','-czf',str(backup),'-C','/var/lib/xln/rdb',*existing],check=True,timeout=12);backup.chmod(0o600)
 unchanged_unrelated(rows(),baseline);protected();save('stopped.json',{'before':baseline,'stopped':owned,'roots':existing,'backup':{'bytes':backup.stat().st_size,'sha256':hashlib.sha256(backup.read_bytes()).hexdigest()},'elapsedSeconds':time.monotonic()-started,'dataReset':False});print('OWNED_SERVICES_STOPPED_CURRENT_STORES_BACKED_UP',flush=True)
elif phase=='install':
 clean(prior);state=json.loads((out/'stopped.json').read_text());ps=rows();unchanged_unrelated(ps,state['before'])
 for p in ps:
  if p['name'] in owned:assert p['pm2_env']['status']=='stopped'
 archive=out/'web.tar.gz';assert hashlib.sha256(archive.read_bytes()).hexdigest()==json.loads((out/'web-manifest.json').read_text())['sha256']
 env=dict(os.environ,EXPECTED_DEPLOY_SHA=target);print(run(['bash',str(out/'prepare-remote-main.sh')],15,env),flush=True);clean(target)
 previous=out/'previous-generated-web.tar.gz';assert not previous.exists()
 with tarfile.open(previous,'w:gz',dereference=False) as t:
  for n in ['frontend/build','ui/dist']:t.add(r/n,arcname=n)
 print(run(['bash','scripts/deployment/web-artifacts.sh','install',str(archive)],15),flush=True)
 files={}
 with tarfile.open(archive) as t:
  for entry in t:
   if not entry.isfile():continue
   expected=hashlib.sha256(t.extractfile(entry).read()).hexdigest();assert hashlib.sha256((r/entry.name).read_bytes()).hexdigest()==expected,entry.name;files[entry.name]=expected
 clean(target);protected();unchanged_unrelated(rows(),state['before']);save('installed.json',{'sha':target,'files':files,'previousWebSha256':hashlib.sha256(previous.read_bytes()).hexdigest(),'elapsedSeconds':time.monotonic()-started});print(json.dumps({'installedFiles':len(files),'runtime':files['ui/dist/runtime.js'],'worker':files['ui/dist/account-worker.js']}),flush=True)
elif phase=='start':
 clean(target);assert json.loads((out/'installed.json').read_text())['sha']==target;state=json.loads((out/'stopped.json').read_text());ps=rows();unchanged_unrelated(ps,state['before']);assert not (out/'started.json').exists()
 for name in owned:
  p=next(x for x in ps if x['name']==name);assert p['pm2_env']['status']=='stopped'
  env={k:v for k,v in os.environ.items() if not k.startswith(('XLN_STAND_','XLN_LOCAL_TEST_LEASE_'))};env['PATH']=str(pathlib.Path(pin).parent)+':'+p['pm2_env']['PATH']
  print(run(['pm2','restart',name,'--update-env'],15,env),flush=True)
 protected();unchanged_unrelated(rows(),state['before']);save('started.json',{'sha':target,'owners':safe(rows()),'at':int(time.time()*1000),'elapsedSeconds':time.monotonic()-started,'dataReset':False,'bootstrapReady':False});print('OWNED_SERVICES_STARTED_PINNED_BUN_CURRENT_WAL',flush=True)
else:raise ValueError('UNKNOWN_PHASE')
