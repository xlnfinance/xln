set -euo pipefail
cd /root/xln
export PATH=/root/.bun/bin:/root/.foundry/bin:$PATH
[ "$(git rev-parse HEAD)" = f3a14e6528415c7c98da7865eb6492becb8c1c61 ]
[ -z "$(git status --porcelain=v1 --untracked-files=all)" ]
bun install --frozen-lockfile
python3 - <<'PY'
import pathlib,tarfile,json,hashlib
p=pathlib.Path('/root/xln-deployment-evidence/f3a14e652');archive=p/'old-generated-web.tar.gz'
assert not archive.exists(),'OLD_GENERATED_ARCHIVE_ALREADY_EXISTS'
with tarfile.open(archive,'w:gz',dereference=False) as t:
 for n in ['frontend/build','ui/dist']:
  if pathlib.Path(n).exists():t.add(n,arcname=n)
print(json.dumps({'oldGeneratedArchive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size}))
expected=json.loads((p/'sha256.json').read_text())['web.tar.gz'];assert hashlib.sha256((p/'web.tar.gz').read_bytes()).hexdigest()==expected
PY
bash scripts/deployment/web-artifacts.sh install /root/xln-deployment-evidence/f3a14e652/web.tar.gz
[ -z "$(git status --porcelain=v1 --untracked-files=all)" ]
python3 - <<'PY'
import hashlib,json,pathlib,tarfile
r=pathlib.Path('/root/xln');p=pathlib.Path('/root/xln-deployment-evidence/f3a14e652');files={}
with tarfile.open(p/'web.tar.gz') as t:
 for entry in t:
  if not entry.isfile():continue
  h=t.extractfile(entry);assert h is not None
  expected=hashlib.sha256(h.read()).hexdigest();assert hashlib.sha256((r/entry.name).read_bytes()).hexdigest()==expected,entry.name;files[entry.name]=expected
result={'head':'f3a14e6528415c7c98da7865eb6492becb8c1c61','installedFiles':files,'sourceClean':True}
(p/'installed-web.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'installedFiles':len(files),'runtimeSha256':files['ui/dist/runtime.js'],'workerSha256':files['ui/dist/account-worker.js'],'sourceClean':True}))
PY
