import pathlib,subprocess,hashlib,json,difflib
r=pathlib.Path('/root/xln');out=pathlib.Path('/root/xln-deployment-evidence/f3a14e652');site=pathlib.Path('/etc/nginx/sites-available/xln')
old=site.read_bytes();assert hashlib.sha256(old).hexdigest()=='1258117df9b47fd091da5c144b7fff297a8a4419c6c4cf6dece7205ece192cb6','LIVE_NGINX_SOURCE_CHANGED'
assert not (out/'nginx-site.before').exists(),'NGINX_BACKUP_EXISTS'
(out/'nginx-site.before').write_bytes(old)
subprocess.run(['/root/.bun/bin/bun','scripts/deployment/configure-wallet-nginx.ts',str(site)],cwd=r,check=True,timeout=10)
new=site.read_bytes()
include=b'    include "/root/xln/scripts/deployment/nginx-wallet.conf";\n\n'
assert new.replace(include,b'',1)==old,'UNEXPECTED_NGINX_CHANGE'
check=subprocess.run(['nginx','-t'],capture_output=True,text=True,timeout=10)
if check.returncode:
 site.write_bytes(old);raise RuntimeError('NGINX_INVALID_OLD_CONFIG_RESTORED:'+check.stderr)
reload=subprocess.run(['nginx','-s','reload'],capture_output=True,text=True,timeout=10)
if reload.returncode:
 site.write_bytes(old);raise RuntimeError('NGINX_RELOAD_FAILED_OLD_FILE_RESTORED:'+reload.stderr)
result={'sourceHead':'f3a14e6528415c7c98da7865eb6492becb8c1c61','beforeSha256':hashlib.sha256(old).hexdigest(),'afterSha256':hashlib.sha256(new).hexdigest(),'onlyChange':'Canonical wallet static routing include; TLS, auth, API/relay and other hosts preserved','nginxTest':check.stderr,'reloadExit':reload.returncode,'diff':''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='before',tofile='after'))}
(out/'nginx-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
