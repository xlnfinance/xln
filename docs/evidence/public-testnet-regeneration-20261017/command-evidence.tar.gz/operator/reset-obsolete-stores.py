import pathlib,subprocess,json,os,hashlib,shutil,socket
root=pathlib.Path('/root/xln');out=pathlib.Path('/root/xln-deployment-evidence/f3a14e652')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='f3a14e6528415c7c98da7865eb6492becb8c1c61'
assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root,text=True)
proof=json.loads((out/'private-preservation.json').read_text());stopped=json.loads((out/'stopped.json').read_text())
rows=json.loads(subprocess.check_output(['pm2','jlist'],text=True,timeout=10))
for r in rows:
 if r['name'] in stopped['ownersStopped']:assert r['pm2_env']['status']=='stopped',r['name']
 else:assert proof['unrelatedPm2'][r['name']]=={'pid':r['pid'],'status':r['pm2_env']['status']},r['name']
for n,v in proof['files'].items():
 p=pathlib.Path(n);assert hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'] and p.stat().st_mode&0o777==v['mode'],'PROTECTED_FILE_CHANGED'
roots=['/var/lib/xln/jdb/anvil-state.json','/var/lib/xln/jdb/anvil2-state.json','/var/lib/xln/rdb/core/prod-main','/var/lib/xln/rdb/core/prod-mesh','/var/lib/xln/rdb/custody/prod','/var/lib/xln/rdb/custody-tmp','/var/lib/xln/rdb/watchtower/prod-main','/var/lib/xln/rdb/watchtower/push-main']
for name in roots:
 p=pathlib.Path(name);assert p.resolve()==p,'RESET_PATH_SYMLINK:'+name
for proc in pathlib.Path('/proc').glob('[0-9]*'):
 try:
  for fd in (proc/'fd').iterdir():
   try:link=os.readlink(fd)
   except OSError:continue
   assert not any(link==r or link.startswith(r+'/') for r in roots),('OPEN_HANDLE',proc.name,link)
 except (FileNotFoundError,PermissionError):pass
records=[]
for name in roots:
 p=pathlib.Path(name)
 if not p.exists():records.append({'path':name,'absent':True});continue
 info={'path':name,'kib':int(subprocess.check_output(['du','-sk',name],text=True,timeout=5).split()[0])}
 if p.is_dir():
  info['files']=sum(len(fs) for _,_,fs in os.walk(p));shutil.rmtree(p)
 else:
  info['bytes']=p.stat().st_size;info['sha256']=hashlib.sha256(p.read_bytes()).hexdigest();p.unlink()
 records.append(info)
for n in ['.mesh-reset-once','.mesh-reset-once.claimed']:
 p=pathlib.Path('/var/lib/xln/rdb/core')/n
 assert not p.is_symlink(),'RESET_MARKER_SYMLINK'
 if p.exists():p.unlink()
p=pathlib.Path('/var/lib/xln/rdb/core/.mesh-reset-once');p.parent.mkdir(parents=True,exist_ok=True);fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.close(fd)
for n,v in proof['files'].items():assert hashlib.sha256(pathlib.Path(n).read_bytes()).hexdigest()==v['sha256'],'PROTECTED_FILE_CHANGED'
result={'head':'f3a14e6528415c7c98da7865eb6492becb8c1c61','reason':'Coordinated regeneration of authorized disposable public Anvil testnet after malformed primary chain checkpoint; no old state attached to fresh chain','deleted':records,'openHandlesBeforeDelete':0,'protectedFilesUnchanged':True,'unrelatedPm2Unchanged':True,'resetMarkerCreated':str(p),'remainingDisk':subprocess.check_output(['df','-Pk','/var/lib/xln'],text=True)}
(out/'reset-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
