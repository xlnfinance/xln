import pathlib,json,urllib.request,hashlib,subprocess,stat,time
out=pathlib.Path('/root/xln-deployment-evidence/f3a14e652')
def get(path):
 with urllib.request.urlopen('http://127.0.0.1:8080'+path,timeout=10) as r:return json.load(r)
h=get('/api/health');assert h['source']['gitHead']=='f3a14e6528415c7c98da7865eb6492becb8c1c61' and not h['source']['dirty']
assert h['coreOk'] and h['systemOk'] and not h['failures'] and not h['degraded']
assert all(s['status']=='done' for s in h['bootstrapTimeline']['stages'])
assert len(h['hubs'])==3 and all(x['online'] for x in h['process']['children'])
assert h['marketMaker']['ok'] and h['custody']['ok'] and h['reset']['lastError'] is None
proof=json.loads((out/'private-preservation.json').read_text())
for n,v in proof['files'].items():
 p=pathlib.Path(n);assert hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'] and stat.S_IMODE(p.stat().st_mode)==v['mode'],'PROTECTED_FILE_CHANGED'
rows=json.loads(subprocess.check_output(['pm2','jlist'],text=True,timeout=10))
for x in rows:
 if x['name'] in proof['unrelatedPm2']:assert proof['unrelatedPm2'][x['name']]=={'pid':x['pid'],'status':x['pm2_env']['status']}
reasons={
'reset_initial_failed-8b8d8e97':'Fresh canonical reset completed; all eight bootstrap stages ready.',
'restore_jadapter_failed-0774f713':'Failed obsolete store restore against unavailable RPC; verified coordinated reset and current live hub J adapters ready.',
'child_unexpected_exit-c186eeb2':'Previous restart-loop deployment retired; current three hubs and MM alive without child error.',
'error-f4e02b7f':'Specific RESTORE_JADAPTER_FAILED ECONNREFUSED retired by verified reset and current live RPC/bootstrap.',
'econnrefused-4288275e':'Both canonical Anvil chains restarted with verified chain IDs; current J adapters/bootstrap ready.',
'custody_bootstrap_failed-1d370915':'September failed bootstrap superseded by current custody healthy bootstrap.',
'hub_recovery_spawn_failed-08d92f22':'September H2 early exit superseded by current three healthy live hubs.',
'_mesh_hub_-0a8ab9fc':'September H1 abort superseded by current live H1 and committed mesh.',
'mm_unexpected_exit-7bf0f27c':'September SIGKILL superseded by current MM offers-ready, no current failure.',
}
for fp in ['entity_frame_head_wire_limit_exceeded-8e5d41c2','runtime_entity_input_apply_failed-b9d200c8','entity_frame_head_wire_limit_exceeded-cf35593d','runtime_entity_input_apply_failed-a1017623','entity_frame_head_wire_limit_exceeded-7ee9a4f5','runtime_entity_input_apply_failed-a64e798b','runtime_halted-5be44192','runtime_halted-d6dce216']:
 reasons[fp]='September oversized obsolete Entity-frame state explicitly discarded in verified coordinated testnet reset; current canonical fresh mesh committed and healthy. Not a claim old oversized frames are supported.'
before=get('/api/debug/incidents?state=open&limit=1000');assert set(x['fingerprint'] for x in before['incidents'])==set(reasons),'INCIDENT_SET_CHANGED'
assert all(x['lastSeen']<h['reset']['startedAt'] for x in before['incidents']),'CURRENT_INCIDENT_PRESENT'
(out/'incidents-before-resolution.json').write_text(json.dumps(before,indent=2)+'\n')
(out/'health-at-resolution.json').write_text(json.dumps(h,indent=2)+'\n')
j=pathlib.Path('/var/lib/xln/rdb/core/prod-mesh.debug-incidents.jsonl');data=j.read_bytes();backup=out/'incident-journal-before-resolution.jsonl';assert not backup.exists();backup.write_bytes(data);backup.chmod(0o600);assert backup.read_bytes()==data
records=[]
for incident in before['incidents']:
 current=next(x for x in get('/api/debug/incidents?state=open&limit=1000')['incidents'] if x['fingerprint']==incident['fingerprint'])
 assert current==incident,'INCIDENT_RECURRED'
 payload=json.dumps({'fingerprint':incident['fingerprint'],'state':'resolved'}).encode()
 req=urllib.request.Request('http://127.0.0.1:8080/api/debug/incidents/state',data=payload,headers={'Content-Type':'application/json'},method='POST')
 with urllib.request.urlopen(req,timeout=10) as r:result=json.load(r)
 assert result['ok'] and result['incident']['state']=='resolved'
 records.append({'fingerprint':incident['fingerprint'],'lastSeen':incident['lastSeen'],'count':incident['count'],'reason':reasons[incident['fingerprint']]})
after=get('/api/debug/incidents?state=open&limit=1000');assert after['returned']==0,'NEW_INCIDENT_BLOCKS_RELEASE'
result={'head':h['source']['gitHead'],'resolved':records,'journalBackup':str(backup),'journalBackupSha256':hashlib.sha256(data).hexdigest(),'journalBackupBytes':len(data),'resetStartedAt':h['reset']['startedAt'],'resetCompletedAt':h['reset']['completedAt'],'openAfter':after['returned'],'protectedFilesUnchanged':True,'unrelatedPm2Unchanged':True,'recurrencePolicy':'store.ts updateDebugIncident unconditionally sets unread on a new event','at':int(time.time()*1000)}
(out/'incident-resolution.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
