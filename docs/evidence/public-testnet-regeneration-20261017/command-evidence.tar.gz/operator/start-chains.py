import pathlib,subprocess,json,urllib.request,time,os
r=pathlib.Path('/root/xln');out=pathlib.Path('/root/xln-deployment-evidence/f3a14e652')
assert json.loads((out/'reset-result.json').read_text())['openHandlesBeforeDelete']==0
rows=json.loads(subprocess.check_output(['pm2','jlist'],text=True,timeout=10))
for name,chain in [('anvil',31337),('anvil2',31338)]:
 e=next(x['pm2_env'] for x in rows if x['name']==name);assert e['status']=='stopped',name
 assert not e.get('args') or '--reset' not in str(e['args']),'PERSISTED_RESET_FORBIDDEN'
 for key in ['ANVIL_TMPDIR','ANVIL_FOUNDRY_DIR']:
  if e.get(key):assert pathlib.Path(e[key]).resolve().is_relative_to(pathlib.Path('/var/lib/xln/jdb')),(key,e[key])
 assert e.get('XLN_JDB_ROOT')=='/var/lib/xln/jdb'
 print(json.dumps({'owner':name,'configuredCache':{k:e[k] for k in ['ANVIL_TMPDIR','ANVIL_FOUNDRY_DIR'] if e.get(k)},'expectedChain':chain}))
subprocess.run(['pm2','restart','anvil','anvil2'],cwd=r,check=True,timeout=15)
subprocess.run(['/root/.bun/bin/bun','scripts/operations/check-anvil-supervision.ts'],cwd=r,check=True,timeout=10)
results=[]
for port,chain in [(8545,31337),(8546,31338)]:
 deadline=time.monotonic()+15;error=None
 while time.monotonic()<deadline:
  try:
   req=urllib.request.Request(f'http://127.0.0.1:{port}',data=b'{"jsonrpc":"2.0","id":1,"method":"eth_chainId","params":[]}',headers={'Content-Type':'application/json'})
   with urllib.request.urlopen(req,timeout=2) as resp:body=json.load(resp)
   assert int(body['result'],16)==chain,body
   results.append({'port':port,'chainId':chain});break
  except Exception as exc:error=str(exc);time.sleep(.25)
 else:raise RuntimeError('CHAIN_START_FAILED:'+str(port)+':'+str(error))
(out/'chain-start.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({'managedTestnetChains':results,'mainnetTransactions':0}))
