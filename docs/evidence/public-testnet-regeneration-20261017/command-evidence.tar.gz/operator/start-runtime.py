import pathlib,subprocess,json,hashlib,socket,urllib.request,time
r=pathlib.Path('/root/xln');out=pathlib.Path('/root/xln-deployment-evidence/f3a14e652');proof=json.loads((out/'private-preservation.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()=='f3a14e6528415c7c98da7865eb6492becb8c1c61'
assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=r,text=True)
for n,v in proof['files'].items():assert hashlib.sha256(pathlib.Path(n).read_bytes()).hexdigest()==v['sha256'],'PROTECTED_FILE_CHANGED'
rows=json.loads(subprocess.check_output(['pm2','jlist'],text=True,timeout=10))
for name in ['xln-server','xln-watchtower']:
 e=next(x['pm2_env'] for x in rows if x['name']==name);assert e['status']=='stopped',name
 assert e['pm_cwd']==str(r) and e['XLN_RDB_ROOT']=='/var/lib/xln/rdb',name
for port in [8080,8087,8088,9100,18090,18091,18092,18093]:
 with socket.socket() as s:
  s.settimeout(.2);assert s.connect_ex(('127.0.0.1',port))!=0,('UNEXPECTED_LISTENER',port)
for pattern in ['scripts/operations/start-custody.sh','core/scripts/operations/custody/start-custody-prod.ts']:
 found=subprocess.run(['pgrep','-f',pattern],capture_output=True,text=True)
 assert found.returncode==1 and not found.stdout,'UNEXPECTED_CUSTODY_PROCESS'
subprocess.run(['pm2','restart','xln-watchtower','xln-server'],cwd=r,check=True,timeout=15)
rows=json.loads(subprocess.check_output(['pm2','jlist'],text=True,timeout=10))
for row in rows:
 if row['name'] in proof['unrelatedPm2']:
  assert proof['unrelatedPm2'][row['name']]=={'pid':row['pid'],'status':row['pm2_env']['status']},'UNRELATED_PROCESS_CHANGED'
result={'head':'f3a14e6528415c7c98da7865eb6492becb8c1c61','managedOwners':[{'name':x['name'],'pid':x['pid'],'status':x['pm2_env']['status']} for x in rows if x['name'] in ['anvil','anvil2','xln-server','xln-watchtower']],'protectedFilesUnchanged':True,'unrelatedPm2Unchanged':True,'bootstrapReady':False}
(out/'runtime-start.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
