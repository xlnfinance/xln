import pathlib,subprocess,json,os,hashlib,time
root=pathlib.Path('/root/xln');out=pathlib.Path('/root/xln-deployment-evidence/f3a14e652')
def run(args,timeout=10):return subprocess.check_output(args,cwd=root,text=True,timeout=timeout).strip()
assert run(['git','rev-parse','HEAD'])=='4dfabd621b913e9e79da315f33d21a1b9708778b','HEAD_CHANGED'
assert run(['git','branch','--show-current'])=='main','MAIN_REQUIRED'
assert not run(['git','status','--porcelain=v1','--untracked-files=all']),'DIRTY_SOURCE'
expected={n:str(root/'scripts/operations'/s) for n,s in [('anvil','start-anvil.sh'),('anvil2','start-anvil2.sh'),('xln-server','start-server.sh'),('xln-watchtower','start-watchtower.sh')]}
rows=json.loads(run(['pm2','jlist']))
for name,path in expected.items():
 matches=[r for r in rows if r.get('name')==name];assert len(matches)==1,'PM2_OWNER_NOT_UNIQUE:'+name
 env=matches[0]['pm2_env'];assert env['pm_exec_path']==path and env['pm_cwd']==str(root),'PM2_OWNER_CHANGED:'+name
other={r['name']:{'pid':r.get('pid'),'status':r['pm2_env'].get('status')} for r in rows if r['name'] not in expected}
protected={}
for n in ['/var/lib/xln/rdb/secrets/main-runtime.seed','/var/lib/xln/rdb/secrets/mesh-root.seed','/var/lib/xln/rdb/watchtower/private-key']:
 p=pathlib.Path(n);assert p.is_file() and not p.is_symlink(),'PROTECTED_FILE_MISSING:'+n
 protected[n]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':p.stat().st_mode&0o777}
p=out/'private-preservation.json'
fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w') as f:json.dump({'files':protected,'unrelatedPm2':other},f)
print(run(['pm2','stop','xln-server','anvil','anvil2','xln-watchtower'],timeout=35))
rows=json.loads(run(['pm2','jlist']))
for r in rows:
 if r['name'] in expected:assert r['pm2_env']['status']=='stopped','OWNER_NOT_STOPPED:'+r['name']
 else:assert other[r['name']]=={'pid':r.get('pid'),'status':r['pm2_env'].get('status')},'UNRELATED_PROCESS_CHANGED:'+r['name']
roots=['/var/lib/xln/jdb/anvil-state.json','/var/lib/xln/jdb/anvil2-state.json','/var/lib/xln/rdb/core/prod-main','/var/lib/xln/rdb/core/prod-mesh','/var/lib/xln/rdb/custody/prod','/var/lib/xln/rdb/custody-tmp','/var/lib/xln/rdb/watchtower/prod-main','/var/lib/xln/rdb/watchtower/push-main']
holders=[]
for proc in pathlib.Path('/proc').glob('[0-9]*'):
 try:
  for fd in (proc/'fd').iterdir():
   try:link=os.readlink(fd)
   except OSError:continue
   if any(link==r or link.startswith(r+'/') for r in roots):holders.append({'pid':int(proc.name),'path':link})
 except (FileNotFoundError,PermissionError):pass
result={'ownersStopped':list(expected),'remainingOpenHandles':holders,'unrelatedPm2Unchanged':True,'protectedFilesUnchanged':all(hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()==v['sha256'] for p,v in protected.items()),'dataReset':False,'sourceUpdated':False}
(out/'stopped.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
assert not holders,'OWNED_STORAGE_HANDLES_REMAIN'
