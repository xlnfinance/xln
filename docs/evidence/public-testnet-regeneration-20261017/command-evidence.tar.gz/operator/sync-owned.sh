set -euo pipefail
cd /root/xln
export PATH=/root/.bun/bin:/root/.foundry/bin:$PATH
export EXPECTED_DEPLOY_SHA=f3a14e6528415c7c98da7865eb6492becb8c1c61
python3 - <<'PY'
import pathlib,json,subprocess,socket
p=pathlib.Path('/root/xln-deployment-evidence/f3a14e652/stopped.json');d=json.loads(p.read_text());assert not d['remainingOpenHandles'] and d['protectedFilesUnchanged']
rows=json.loads(subprocess.check_output(['pm2','jlist'],text=True,timeout=10))
for r in rows:
 if r['name'] in d['ownersStopped']:assert r['pm2_env']['status']=='stopped',r['name']
for port in [8080,8087,8088,8545,8546,9100,18090,18091,18092,18093]:
 with socket.socket() as s:
  s.settimeout(.2);assert s.connect_ex(('127.0.0.1',port))!=0,('OWNER_PORT_BUSY',port)
print('OWNED_PROCESSES_AND_PORTS_STOPPED')
PY
bash /root/xln-deployment-evidence/f3a14e652/prepare-remote-main.sh
python3 - <<'PY'
import pathlib,subprocess
p=pathlib.Path('/root/xln/.git/info/exclude');b=pathlib.Path('/root/xln-deployment-evidence/f3a14e652/git-info-exclude.before').read_bytes()
assert p.read_bytes()==b+b'\n# Current canonical operational stand metadata (bootstrap until main update).\n.xln-stand-lock/\n'
assert '.xln-stand-lock/' in pathlib.Path('/root/xln/.gitignore').read_text().splitlines()
p.write_bytes(b)
assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],text=True)
print('SOURCE_FAST_FORWARD_CLEAN:git-info-exclude-restored')
PY
