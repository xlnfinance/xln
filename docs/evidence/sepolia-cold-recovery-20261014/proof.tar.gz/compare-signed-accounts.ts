import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { decryptRuntimeRecoveryBundle } from '../../core/storage/recovery/bundle/crypto';
import { canonicalizeStorageAuditValue } from '../../core/storage/canonical-hash';
import { deepStrictEqual, rejects } from 'node:assert/strict';
const dir='/Users/zigota/.config/xln/sepolia-cold-recovery-4c4413992';
const phrase=readFileSync('/Users/zigota/.config/xln/sepolia-demo-e4db444ee/seed.mnemonic','utf8').trim();
const files=['source-backup.json','before-tower-backup.json','selected-tower-backup.json','after-tower-backup.json',...process.argv.slice(2)];
const keys=['state','currentHeight','currentFrame','currentFrameHanko','counterpartyFrameHanko','proofHeader','currentDisputeHash','currentDisputeProofBodyHash','currentDisputeProofHanko','currentDisputeProofNonce','currentDisputeProofProposerIsLeft','counterpartyDisputeHash','counterpartyDisputeProofBodyHash','counterpartyDisputeProofHanko','counterpartyDisputeProofNonce','counterpartyDisputeProofProposerIsLeft'];
const rows=[];
for(const file of files){
 const encrypted=JSON.parse(readFileSync(dir+'/'+file,'utf8')).bundle;
 const decoded=await decryptRuntimeRecoveryBundle(encrypted,phrase);
 const entities=decoded.checkpoint!.eReplicas as Array<[string,{entityId:string,state:{accounts:Map<string,Record<string,unknown>>}}]>;
 const accounts=entities.flatMap(([,e])=>[...e.state.accounts].map(([counterparty,a])=>({entityId:e.entityId,counterparty,canonical:canonicalizeStorageAuditValue(Object.fromEntries(keys.filter(key=>key in a).map(key=>[key,a[key]]))),height:a.currentHeight})));
 rows.push({file,runtimeId:decoded.runtimeId,height:decoded.runtimeHeight,checkpointHash:decoded.checkpointHash,bundleHash:encrypted.bundleHash,accounts});
}
for(const row of rows.slice(1))deepStrictEqual(row.accounts,rows[0]!.accounts,`SIGNED_ACCOUNT_CHANGED:${row.file}`);
const tampered=JSON.parse(readFileSync(dir+'/'+files[0],'utf8')).bundle;
tampered.ciphertext=tampered.ciphertext.slice(0,2)+(tampered.ciphertext[2]==='0'?'1':'0')+tampered.ciphertext.slice(3);
await rejects(()=>decryptRuntimeRecoveryBundle(tampered,phrase));
const result={kind:'RECOVERED_SIGNED_ACCOUNTS_IDENTICAL',source:'4c4413992b1f11a5cbdcb5e1fcaed7dafa69483c',checkedFields:keys,ciphertextTamperingRejected:true,comparison:'Exact canonical committed Account state, accepted frame, both frame signatures and unilateral dispute evidence across authenticated exports; runtime checkpoints may advance.',snapshots:rows.map(({accounts,...row})=>({...row,accounts:accounts.map(({canonical,...account})=>({...account,sha256:createHash('sha256').update(JSON.stringify(canonical)).digest('hex')}))}))};
writeFileSync('.logs/sepolia-cold-recovery-20261014/signed-account-equality.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
