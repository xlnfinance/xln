import { chromium, expect, type BrowserContext, type Page } from '../../ui/node_modules/@playwright/test';
import { existsSync, readFileSync, writeFileSync, chmodSync } from 'node:fs';
import { LOCAL_PASSWORD } from '../../ui/tests/stack';
const base='https://sepolia.xln.finance';
const sha='4c4413992b1f11a5cbdcb5e1fcaed7dafa69483c';
const dir='/Users/zigota/.config/xln/sepolia-cold-recovery-4c4413992';
const seedPath='/Users/zigota/.config/xln/sepolia-demo-e4db444ee/seed.mnemonic';
const logs='.logs/sepolia-cold-recovery-20261014';
const phrase=readFileSync(seedPath,'utf8').trim();
const sourceProfile=JSON.parse(readFileSync(dir+'/active-profile.json','utf8')).profile;
const profile=dir+'/tower-profile';
if(existsSync(profile))throw Error('FRESH_PROFILE_ALREADY_EXISTS:inspect before retry');
let source:BrowserContext|undefined,target:BrowserContext|undefined,page:Page|undefined;
const pageErrors:string[]=[];const fundingRequests:string[]=[];
const observe=(p:Page)=>{p.on('pageerror',e=>pageErrors.push(e.message.replaceAll(phrase,'[REDACTED]')));p.on('request',r=>{if(r.method()==='POST'&&new URL(r.url()).pathname.startsWith('/api/faucet'))fundingRequests.push(new URL(r.url()).pathname);});};
const stage=(stage:string,fields:Record<string,unknown>={})=>console.log(JSON.stringify({stage,...fields}));
async function exportBackup(p:Page,path:string){const promised=p.waitForEvent('download');await p.getByTestId('evidence-export').click();await (await promised).saveAs(path);chmodSync(path,0o600);}
try{
 const health=await (await fetch(base+'/api/health')).json();expect(health.source.gitHead).toBe(sha);expect(health.source.dirty).toBe(false);
 source=await chromium.launchPersistentContext(sourceProfile,{headless:true,viewport:{width:1280,height:860}});page=source.pages()[0]??await source.newPage();for(const other of source.pages())if(other!==page)await other.close();observe(page);
 await page.goto(base);await page.getByRole('button',{name:'Continue',exact:true}).click();await page.getByLabel('Password',{exact:true}).fill(LOCAL_PASSWORD);await page.getByRole('button',{name:'Unlock',exact:true}).click();await expect(page.getByTestId('token-net-USDT')).toHaveText('75.00',{timeout:40000});
 const entityId=await page.getByTestId('home-entity-id').textContent();
 await page.getByTestId('home-sovereignty').click();const evidenceBefore=await page.getByTestId('evidence-preview').innerText();expect(evidenceBefore).toContain('co-signed');
 if(await page.getByTestId('watchtower-row').count()===0){await page.getByTestId('watchtower-url').fill(base);await page.getByTestId('watchtower-add').click();}
 await expect(page.getByTestId('sovereignty-watchtower')).toHaveAttribute('data-covered','yes',{timeout:25000});
 expect(await page.getByTestId('watchtower-error').allTextContents()).toEqual([]);
 const coverage=await page.getByTestId('watchtower-coverage-backup').innerText();const match=coverage.match(/#([\d,]+)/);expect(match).not.toBeNull();const minimumHeight=Number(match![1].replaceAll(',',''));
 await exportBackup(page,dir+'/before-tower-backup.json');
 stage('TOWER_BACKUP_CONFIRMED',{entityId,minimumHeight,evidenceBefore});
 await source.close();source=undefined;
 target=await chromium.launchPersistentContext(profile,{headless:true,viewport:{width:1280,height:860}});page=target.pages()[0]??await target.newPage();observe(page);await page.goto(base);expect(await page.evaluate(()=>indexedDB.databases())).toEqual([]);
 await expect(page.getByTestId('gate-stack')).toHaveAttribute('data-state','online',{timeout:20000});await page.getByRole('button',{name:/Restore a wallet/}).click();
 const started=performance.now();await page.locator('textarea').fill(phrase);await page.getByTestId('restore-from-tower').check();await page.getByTestId('restore-tower-url').fill(base);
 const responsePromise=page.waitForResponse(r=>r.request().method()==='POST'&&new URL(r.url()).pathname==='/api/tower/restore',{timeout:20000});
 await page.getByRole('button',{name:'Restore wallet',exact:true}).click();const response=await responsePromise;expect(response.ok()).toBe(true);const payload=await response.json();expect(payload.ok).toBe(true);const receipt=payload.receipt;
 expect(receipt.height).toBeGreaterThanOrEqual(minimumHeight);expect(receipt.bundleHash).toMatch(/^0x[0-9a-f]{64}$/i);expect(payload.bundles).toHaveLength(1);expect(payload.bundles[0].bundleHash).toBe(receipt.bundleHash);
 writeFileSync(dir+'/selected-tower-backup.json',JSON.stringify({bundle:payload.bundles[0]}),{mode:0o600});
 await expect(page.getByRole('heading',{name:'Set a local password'})).toBeVisible({timeout:20000});const discoveryMs=Math.round(performance.now()-started);
 await page.getByLabel('Password',{exact:true}).fill(LOCAL_PASSWORD);await page.getByLabel('Confirm password',{exact:true}).fill(LOCAL_PASSWORD);await page.getByRole('button',{name:'Save and open',exact:true}).click();
 await expect(page.locator('[data-testid="nav-home"]:visible, [role="alert"]').first()).toBeVisible({timeout:Math.max(1,60000-(performance.now()-started))});expect(await page.getByRole('alert').allTextContents()).toEqual([]);
 await expect(page.getByTestId('token-net-USDT')).toHaveText('75.00',{timeout:Math.max(1,60000-(performance.now()-started))});const recoveredMs=Math.round(performance.now()-started);expect(recoveredMs).toBeLessThan(60000);expect(await page.getByTestId('home-entity-id').textContent()).toBe(entityId);expect(await page.evaluate(()=>'__xln' in window)).toBe(false);
 await page.getByTestId('home-sovereignty').click();const evidenceAfter=await page.getByTestId('evidence-preview').innerText();expect(evidenceAfter).toBe(evidenceBefore);await exportBackup(page,dir+'/after-tower-backup.json');
 await page.getByTestId('nav-home').locator('visible=true').first().click();await page.screenshot({path:logs+'/tower-restored.png',fullPage:true});
 expect(pageErrors).toEqual([]);expect(fundingRequests).toEqual([]);
 const result={kind:'PUBLIC_COLD_TOWER_RESTORE',source:sha,entityId,runtimeId:receipt.runtimeId,receipt,minimumHeight,emptyIndexedDb:true,sourceClosedBeforeRestore:true,discoveryMs,recoveredMs,balance:'75.00 USDT',evidenceBefore,evidenceAfter,additionalFunding:0,additionalPayments:0,pageErrors,fundingRequests,profile};
 writeFileSync(logs+'/tower-result.json',JSON.stringify(result,null,2)+'\n');writeFileSync(dir+'/active-profile.json',JSON.stringify({profile,previous:sourceProfile,source:sha,reason:'Fresh-device tower restore extended the copied Runtime; previous profiles retained, do not run concurrently.'},null,2)+'\n',{mode:0o600});stage('RESTORED',result);
}catch(error){console.log('COLD_TOWER_FAILURE '+(error instanceof Error?error.message:String(error)).replaceAll(phrase,'[REDACTED]'));if(page)await page.screenshot({path:dir+'/tower-failure.png',fullPage:true}).catch(()=>{});process.exitCode=1;}finally{await source?.close();await target?.close();}
