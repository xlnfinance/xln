#!/bin/bash
# Review-only preparation. Run on root@xln.finance through a retained async handle.
# Normal path is ~30-60s; bounded recovery may take longer. Never restore the WAL archive.
set -euo pipefail
umask 077
old_sha=e4db444ee98abf9cc567b8f9bd431d97c1414b95
old_release=/opt/xln/releases/e4db444ee
target_sha=${1:?exact candidate SHA required}
[[ "$target_sha" =~ ^[0-9a-f]{40}$ ]]
target_release=/opt/xln/releases/${target_sha:0:9}
sha=$old_sha
release=$old_release
state=/var/lib/xln/sepolia-20261011
catalog="$state/mesh/jurisdictions.json"
nginx=/etc/nginx/sites-available/xln-sepolia
bunbin=/opt/xln/toolchains/bun-1.4.0/bun-linux-x64/bun
new_rpc=https://rpc.sepolia.ethpandaops.io
snapshot="$state/backups/release-${target_sha:0:9}-$(date -u +%Y%m%dT%H%M%SZ)"
account_url='http://127.0.0.1:18110/api/account/status?hubEntityId=0x2d08d3bb8f4102fb07fecef0b59f052139c99aa996239ebfc55baac82ac54dd6&counterpartyEntityId=0xd0aa872e92c2d6c5dc913ab4ee3600b1b144c097d898d29b23bb7aa63b881909&tokenIds=1'

stage() { printf 'RELEASE_PROMOTION %s elapsed=%ss\n' "$1" "$SECONDS"; }
assert_source() {
  test "$(git -C "$release" rev-parse HEAD)" = "$sha" &&
    test -z "$(git -C "$release" status --porcelain)"
}
atomic_copy() {
  python3 - "$1" "$2" <<'PY'
import os,sys,stat
from pathlib import Path
source,target=map(Path,sys.argv[1:]);tmp=target.with_name(target.name+'.rpc-switch-'+str(os.getpid()))
with tmp.open('wb') as f:
    f.write(source.read_bytes());f.flush();os.fsync(f.fileno())
os.chmod(tmp,stat.S_IMODE(source.stat().st_mode));os.replace(tmp,target)
fd=os.open(target.parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
PY
}
health() {
  curl --max-time 2 -fsS http://127.0.0.1:18100/api/health > "$snapshot/$1-health.json" 2>/dev/null &&
  "$bunbin" -e 'const h=await Bun.file(process.argv[1]).json();process.exit(h.systemOk===true&&h.coreOk===true&&h.source?.gitHead===process.argv[2]&&h.source.dirty===false?0:1)' "$snapshot/$1-health.json" "$sha"
}
tower_health() {
  curl --max-time 2 -fsS http://127.0.0.1:19100/api/tower/healthz > "$snapshot/$1-tower.json" 2>/dev/null &&
  "$bunbin" -e 'const h=await Bun.file(process.argv[1]).json();process.exit(h.ok===true&&h.sweep?.enabled===true&&h.sweep.healthy===true&&h.sweep.consecutiveFailures===0&&(h.sweep.itemErrors??0)===0&&h.signerAddress==="0x50c7fb1565988eb94bca5c525c4e5431a48cf9a4"?0:1)' "$snapshot/$1-tower.json"
}
wait_ready() {
  local label=$1 deadline=$((SECONDS+40)) first_good=-1
  while test "$SECONDS" -lt "$deadline"; do
    if health "$label" && tower_health "$label"; then
      if test "$first_good" -lt 0; then first_good=$SECONDS; fi
      if test "$((SECONDS-first_good))" -ge 12; then return 0; fi
    else first_good=-1
    fi
    sleep 2
  done
  return 1
}
verify_p6() {
  local label=$1 rpc=${2:-$new_rpc}
  curl --max-time 3 -fsS "$account_url" > "$snapshot/$label-p6-local.json" &&
  "$bunbin" -e 'const a=await Bun.file(process.argv[1]).json();process.exit(a.success===true&&a.hasAccount===true&&a.ready===true&&a.runtime?.halted===false&&a.pendingFrameHeight===null&&a.tokens?.find(t=>t.tokenId===1)?.delta?.collateral==="0"?0:1)' "$snapshot/$label-p6-local.json" &&
  (cd "$release" && timeout --kill-after=2s 12s "$bunbin" - "$rpc" > "$snapshot/$label-p6-chain.json" <<'TS'
import { FetchRequest, JsonRpcProvider, ZeroHash } from 'ethers';
import { Depository__factory } from './jurisdictions/typechain-types';
import { computeAccountKey } from './core/jurisdiction/adapter/events/contract-codec';
const request=new FetchRequest(process.argv[2]!);request.timeout=5000;
const provider=new JsonRpcProvider(request,11155111,{cacheTimeout:-1,batchMaxCount:1,staticNetwork:true});
try {
  if(await provider.send('eth_chainId',[])!=='0xaa36a7')throw Error('P6_CHAIN_MISMATCH');
  const block=await provider.getBlock('latest');if(!block)throw Error('P6_BLOCK_MISSING');
  const contract=Depository__factory.connect('0x4e7333463cdde39aa58587d58af3f66757117f61',provider);
  const key=computeAccountKey('0xd0aa872e92c2d6c5dc913ab4ee3600b1b144c097d898d29b23bb7aa63b881909','0x2d08d3bb8f4102fb07fecef0b59f052139c99aa996239ebfc55baac82ac54dd6');
  const at={blockTag:block.number};
  const collateral=(await contract._collaterals(key,1,at)).collateral;
  const disputeHash=(await contract._accounts(key,at)).disputeHash;
  if(collateral!==0n||disputeHash!==ZeroHash)throw Error('P6_EXIT_STATE_MISMATCH');
  console.log(JSON.stringify({block:block.number,blockHash:block.hash,collateral:'0',activeDispute:false,transactionsSent:0}));
} finally {provider.destroy();}
TS
  )
}
restore_configs() {
  atomic_copy "$snapshot/start.sh" "$state/start.sh" &&
  atomic_copy "$snapshot/start-watchtower.sh" "$state/start-watchtower.sh" &&
  atomic_copy "$snapshot/jurisdictions.json" "$catalog"
}
rollback() {
  trap - ERR INT TERM
  set +e
  sha=$old_sha
  release=$old_release
  stage failed-restoring-config-only
  atomic_copy "$snapshot/nginx.maintenance.conf" "$nginx"
  nginx -t && systemctl reload nginx
  pm2 stop xln-sepolia xln-sepolia-watchtower > "$snapshot/rollback-stop.log" 2>&1
  # The archive is recovery evidence only. Accepted WAL inputs are never rewound.
  if restore_configs &&
     pm2 restart xln-sepolia xln-sepolia-watchtower > "$snapshot/rollback-start.log" 2>&1 &&
     wait_ready rollback && assert_source && verify_p6 rollback &&
     atomic_copy "$snapshot/nginx.conf" "$nginx" && nginx -t && systemctl reload nginx; then
    pm2 save > "$snapshot/rollback-save.log" 2>&1
    stage rollback-config-healthy
  else
    atomic_copy "$snapshot/nginx.maintenance.conf" "$nginx"
    nginx -t && systemctl reload nginx
    pm2 stop xln-sepolia xln-sepolia-watchtower > "$snapshot/failure-stop.log" 2>&1
    pm2 save > "$snapshot/failure-save.log" 2>&1
    stage rollback-unhealthy-maintenance-retained
  fi
  exit 1
}

stage preflight
assert_source
test "$(git -C "$target_release" rev-parse HEAD)" = "$target_sha"
test -z "$(git -C "$target_release" status --porcelain)"
printf '%s  %s\n' \
  f07f6448cdd5f9229bfbac8e2bd2bc4307ac6b2050e32a2c30d1c34a051df19e "$state/start.sh" \
  91515e4418c045e4c9655196588aae0b76f1588d316d236c553f56f948d33826 "$state/start-watchtower.sh" \
  3802883dfbe4cc64cf1bbd5286ba3f473bba8023d5e68a3482fcef84172fa113 "$catalog" \
  64d5d0e5c40e1f1c0e4173f7664c46644c35d30a8843ba65cb6afc676e160540 "$nginx" | sha256sum -c -
test ! -e "$snapshot"
state_bytes=$(du -sb --exclude=backups "$state" | cut -f1)
free_bytes=$(df -PB1 "$state" | awk 'NR==2 {print $4}')
# Leave at least 5 GiB free after the uncompressed cold archive and a small margin.
test "$free_bytes" -gt "$((state_bytes+5368709120+67108864))"
mkdir "$snapshot"
cp -p "$state/start.sh" "$snapshot/start.sh"
cp -p "$state/start-watchtower.sh" "$snapshot/start-watchtower.sh"
cp -p "$catalog" "$snapshot/jurisdictions.json"
cp -p "$nginx" "$snapshot/nginx.conf"
health before
python3 - "$snapshot/nginx.conf" "$snapshot/nginx.maintenance.conf" <<'PY'
from pathlib import Path
import sys
source,target=map(Path,sys.argv[1:]);text=source.read_text();line='    listen 443 ssl http2;'
assert text.count(line)==1 and 'server_name sepolia.xln.finance;' in text
assert '    if ($uri != "/rpc") { return 503; }' not in text
target.write_text(text.replace(line,line+'\n    if ($uri != "/rpc") { return 503; }'))
PY
trap rollback ERR INT TERM
atomic_copy "$snapshot/nginx.maintenance.conf" "$nginx"
nginx -t
systemctl reload nginx
stage stopping
pm2 stop xln-sepolia xln-sepolia-watchtower > "$snapshot/stop.log" 2>&1
if ss -ltnp | grep -Eq ':(18100|18110|19100) '; then echo LISTENER_STILL_OPEN >&2; false; fi
stage cold-archive
timeout --kill-after=2s 20s tar --sparse --exclude=./backups -cf "$snapshot/state.partial" -C "$state" .
mv "$snapshot/state.partial" "$snapshot/state.tar"
sha256sum "$snapshot/state.tar" > "$snapshot/state.sha256"
python3 - "$state" "$new_rpc" "$old_release" "$target_release" <<'PYCHANGE'
import json,os,stat,sys
from pathlib import Path
base=Path(sys.argv[1]);rpc,old_release,new_release=sys.argv[2:5]
d=json.loads((base/'mesh/jurisdictions.json').read_text());entries=[j for j in d['jurisdictions'].values() if j.get('primary') is True and j.get('chainId')==11155111]
assert len(entries)==1 and entries[0]['rpc'].rstrip('/')==rpc
for name in ['start.sh','start-watchtower.sh']:
    path=base/name;body=path.read_text();assert body.count('cd '+old_release)==1
    body=body.replace('cd '+old_release,'cd '+new_release)
    tmp=path.with_name(path.name+'.release-'+str(os.getpid()))
    with tmp.open('w') as f:f.write(body);f.flush();os.fsync(f.fileno())
    os.chmod(tmp,stat.S_IMODE(path.stat().st_mode));os.replace(tmp,path)
    fd=os.open(path.parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
PYCHANGE
bash -n "$state/start.sh" "$state/start-watchtower.sh"
sha=$target_sha
release=$target_release
stage restarting
pm2 restart xln-sepolia xln-sepolia-watchtower > "$snapshot/start.log" 2>&1
wait_ready candidate
assert_source
verify_p6 candidate
python3 - "$catalog" "$new_rpc" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]));p=[j for j in d['jurisdictions'].values() if j.get('primary') is True and j.get('chainId')==11155111]
assert len(p)==1 and p[0]['rpc'].rstrip('/')==sys.argv[2]
PY
stage reopening
python3 - "$snapshot/nginx.conf" "$snapshot/nginx.candidate.conf" "$old_release" "$target_release" <<'PYOPEN'
from pathlib import Path
import sys
source,target=map(Path,sys.argv[1:3]);old,new=sys.argv[3:5];s=source.read_text();needle='root '+old+'/ui/dist;'
assert s.count(needle)==1;target.write_text(s.replace(needle,'root '+new+'/ui/dist;'))
PYOPEN
atomic_copy "$snapshot/nginx.candidate.conf" "$nginx"
nginx -t
systemctl reload nginx
public_ready=0
for attempt in $(seq 1 10); do
  if curl --max-time 3 -fsS https://sepolia.xln.finance/api/health > "$snapshot/public-health.json" &&
     "$bunbin" -e 'const h=await Bun.file(process.argv[1]).json();process.exit(h.systemOk===true&&h.coreOk===true&&h.source?.gitHead===process.argv[2]&&h.source.dirty===false?0:1)' "$snapshot/public-health.json" "$sha"; then public_ready=1; break; fi
  sleep 1
done
test "$public_ready" -eq 1
pm2 save > "$snapshot/save.log" 2>&1
sha256sum "$state/start.sh" "$state/start-watchtower.sh" "$catalog" "$nginx" > "$snapshot/after-config.sha256"
trap - ERR INT TERM
stage healthy
printf 'RELEASE_PROMOTION_EVIDENCE %s\n' "$snapshot"
