#!/bin/bash
set -euo pipefail
old=/opt/xln/releases/e4db444ee
new=/opt/xln/releases/4c4413992
sha=4c4413992b1f11a5cbdcb5e1fcaed7dafa69483c
manifest=/tmp/release-4c4413992-manifest.json
test ! -e "$new"
test "$(git -C "$old" rev-parse HEAD)" = e4db444ee98abf9cc567b8f9bd431d97c1414b95
test -z "$(git -C "$old" status --porcelain)"
test ! -s "$old/.git/objects/info/alternates"
python3 - "$manifest" <<'VERIFY'
import json,hashlib,sys
from pathlib import Path
m=json.load(open(sys.argv[1]))
for a in m['artifacts']:
 b=(Path('/tmp')/a['file']).read_bytes()
 assert len(b)==a['bytes'] and hashlib.sha256(b).hexdigest()==a['sha256'],a['file']
VERIFY
free_bytes=$(df -PB1 /opt/xln | awk 'NR==2 {print $4}')
test "$free_bytes" -gt 5599395840
git clone --local --no-checkout "$old" "$new"
git -C "$new" fetch /tmp/release-4c4413992.bundle HEAD
git -C "$new" checkout --detach "$sha"
ln -s /opt/xln/releases/a3cc31669/node_modules "$new/node_modules"
mkdir -p "$new/ui/dist"
tar -xzf /tmp/release-4c4413992-ui.tar.gz -C "$new/ui/dist"
python3 - "$manifest" "$new" <<'VERIFY'
import json,hashlib,sys
from pathlib import Path
m=json.load(open(sys.argv[1]));root=Path(sys.argv[2])
for f in m['uiFiles']:
 b=(root/'ui/dist'/f['path']).read_bytes()
 assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256'],f['path']
print('STAGED',m['sourceSha'],'UI_FILES',len(m['uiFiles']))
VERIFY
test -z "$(git -C "$new" status --porcelain)"
test ! -s "$new/.git/objects/info/alternates"
df -B1 /opt/xln
