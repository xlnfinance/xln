import { expect, test, type Page } from '@playwright/test';
import type { RuntimeReplica } from '../../../core/runtime/types';
import { deriveDelta } from '../../../core/account/utils';
import { setBankPolicy } from './bank-policy';

async function accountMoney(page: Page) {
  const owner = await page.getByTestId('context-current').getAttribute('data-entity-id');
  if (!owner) throw new Error('SVELTE_OWNER_MISSING');
  const data = await page.evaluate(entityId => {
    const env = (window as Window & { __xln: { liveRuntimeSnapshot: RuntimeReplica } }).__xln.liveRuntimeSnapshot;
    const entity = [...env.state.eReplicas.values()].find(item => item.entityId === entityId);
    const entry = entity && [...entity.state.accounts.entries()][0];
    if (!entry) throw new Error('SVELTE_ACCOUNT_MISSING');
    const [hubId, account] = entry;
    const delta = account.state.deltas.get(1);
    if (!delta) throw new Error('SVELTE_USDC_MISSING');
    return { ownerId: entityId, hubId, tokenId: 1, delta, isLeft: account.state.leftEntity === entityId, pending: Boolean(account.pendingFrame) };
  }, owner);
  const balance = deriveDelta(data.delta, data.isLeft);
  return { ...data, owned: balance.outCollateral + balance.outPeerCredit - balance.inOwnCredit };
}

test('Svelte signed savings and loan preserve exact money without leaving /app', { tag: '@functional' }, async ({ page }) => {
  const errors: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.goto('/app');
  await page.getByRole('button', { name: 'Open test wallet', exact: true }).click();
  await expect(page.getByTestId('context-current')).toBeVisible();
  await page.getByRole('button', { name: 'Accounts', exact: true }).click();
  await page.getByTestId('hub-discovery-card').filter({ hasText: 'H1' }).getByTestId('hub-connect-button').click();
  await expect(page.getByTestId('account-preview').first()).toBeVisible();
  await page.getByRole('button', { name: 'Faucet', exact: true }).first().click();
  await expect.poll(async () => (await accountMoney(page)).owned).toBe(100_000_000n);
  const ids = await accountMoney(page);
  await setBankPolicy(page, ids, { termId: '1d', savingsInterestBps: 100, loanInterestBps: 100, maxPrincipal: 2_000_000n });
  await page.getByRole('button', { name: 'Lending', exact: true }).click();
  const panel = page.getByTestId('lending-panel');
  await panel.getByLabel('Term', { exact: true }).selectOption('1d');
  await panel.getByLabel('Amount', { exact: true }).fill('5');
  await expect(panel.getByRole('button', { name: 'Authorize this maximum risk', exact: true })).toBeVisible();
  await panel.getByRole('button', { name: 'Authorize this maximum risk', exact: true }).click();
  await expect(page.getByTestId('lending-offer-submit')).toBeEnabled();
  await page.getByTestId('lending-offer-submit').click();
  await expect.poll(async () => (await accountMoney(page)).owned).toBe(95_000_000n);
  await expect(panel.getByText(/5 USDC · open/)).toBeVisible();
  await panel.getByLabel('Action', { exact: true }).selectOption('borrow');
  await panel.getByLabel('Amount', { exact: true }).fill('2');
  await panel.getByLabel('Maximum rate (basis points)', { exact: true }).fill('100');
  await expect(panel.getByRole('button', { name: /^Accept as credit:/ })).toBeVisible();
  await panel.getByRole('button', { name: /^Accept as credit:/ }).click();
  await expect(page.getByTestId('lending-borrow-submit')).toBeEnabled();
  await page.getByTestId('lending-borrow-submit').click();
  await expect.poll(async () => (await accountMoney(page)).owned).toBe(97_000_000n);
  await expect(page.getByTestId('lending-repay-submit')).toBeEnabled();
  await page.getByTestId('lending-repay-submit').click();
  await expect(page.getByTestId('lending-loan-row')).toContainText('repaid');
  const repaid = await accountMoney(page);
  const response = await page.request.get('/api/lending/state', { params: { hubEntityId: ids.hubId, userEntityId: ids.ownerId, tokenId: '1' } });
  expect(response.ok()).toBe(true);
  const state = await response.json();
  expect(state.loans).toHaveLength(1);
  expect(state.loans[0].repaidAmount).toMatch(/^[0-9]+$/);
  expect(repaid.owned).toBe(97_000_000n - BigInt(state.loans[0].repaidAmount));
  await expect(page).toHaveURL(/\/app#accounts\/lending$/);
  expect(errors).toEqual([]);
});
